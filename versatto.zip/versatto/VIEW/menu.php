<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['login'])) {
    header("Location: /versatto/VIEW/index.php");
    exit;
}
$usuario_logado = $_SESSION['login'];
$nivel          = $_SESSION['nivel'] ?? 2;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="/versatto/VIEW/css/style.css?v=2">
    <link rel="icon" href="/versatto/VIEW/images/logo.jpeg">
    <title>Versatto - Móveis Planejados</title>
</head>
<body>

<!-- Sidenav -->
<ul id="slide-out" class="sidenav">
    <li>
        <div class="user-view">
            <img src="/versatto/VIEW/images/logo.jpeg" style="max-width:160px;border-radius:4px">
            <br>
            <span class="white-text name" style="font-weight:bold"><?php echo htmlspecialchars($usuario_logado); ?></span><br>
            <span class="white-text email" style="font-size:.85rem"><?php echo $nivel==1?'Administrador':'Operador'; ?></span>
        </div>
    </li>
    <li><a href="/versatto/VIEW/home.php" class="white-text"><i class="material-icons">home</i>Home</a></li>
    <li><div class="divider"></div></li>
    <li><a class="subheader white-text" style="color:#f5c842!important">CADASTROS</a></li>
    <li><a href="/versatto/VIEW/CLIENTE/lstcliente.php"       class="white-text"><i class="material-icons">people</i>Clientes</a></li>
    <li><a href="/versatto/VIEW/FORNECEDOR/lstfornecedor.php" class="white-text"><i class="material-icons">business</i>Fornecedores</a></li>
    <li><a href="/versatto/VIEW/PRODUTO/lstproduto.php"       class="white-text"><i class="material-icons">inventory_2</i>Produtos</a></li>
    <li><a href="/versatto/VIEW/TIPOPRODUTO/lsttipoproduto.php" class="white-text"><i class="material-icons">category</i>Tipo Produto</a></li>
    <li><div class="divider"></div></li>
    <li><a class="subheader white-text" style="color:#f5c842!important">MOVIMENTAÇÃO</a></li>
    <li><a href="/versatto/VIEW/COMPRA/lstcompra.php"  class="white-text"><i class="material-icons">add_shopping_cart</i>Compras</a></li>
    <li><a href="/versatto/VIEW/VENDA/lstvenda.php"    class="white-text"><i class="material-icons">point_of_sale</i>Vendas</a></li>
    <li><div class="divider"></div></li>
    <li><a class="subheader white-text" style="color:#f5c842!important">RELATÓRIOS</a></li>
    <li><a href="/versatto/VIEW/RELATORIO/relcompra.php"  class="white-text"><i class="material-icons">assessment</i>Rel. Compras</a></li>
    <li><a href="/versatto/VIEW/RELATORIO/relvenda.php"   class="white-text"><i class="material-icons">bar_chart</i>Rel. Vendas</a></li>
    <li><a href="/versatto/VIEW/RELATORIO/relestoque.php" class="white-text"><i class="material-icons">warehouse</i>Estoque</a></li>
    <li><div class="divider"></div></li>
    <li><a href="/versatto/VIEW/logout.php" class="white-text"><i class="material-icons">logout</i>Sair</a></li>
</ul>

<!-- Navbar -->
<nav class="versatto-nav">
    <div class="nav-wrapper container">
        <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <a href="/versatto/VIEW/home.php" class="brand-logo">
            <img src="/versatto/VIEW/images/logo.jpeg" alt="Versatto">
        </a>
        <ul class="right hide-on-med-and-down">
            <li><a href="/versatto/VIEW/CLIENTE/lstcliente.php"><i class="material-icons left">people</i>Clientes</a></li>
            <li><a href="/versatto/VIEW/FORNECEDOR/lstfornecedor.php"><i class="material-icons left">business</i>Fornecedores</a></li>
            <li><a href="/versatto/VIEW/PRODUTO/lstproduto.php"><i class="material-icons left">inventory_2</i>Produtos</a></li>
            <li><a href="/versatto/VIEW/COMPRA/lstcompra.php"><i class="material-icons left">add_shopping_cart</i>Compras</a></li>
            <li><a href="/versatto/VIEW/VENDA/lstvenda.php"><i class="material-icons left">point_of_sale</i>Vendas</a></li>
            <li><a href="/versatto/VIEW/logout.php"><i class="material-icons left">logout</i><?php echo htmlspecialchars($usuario_logado); ?></a></li>
        </ul>
    </div>
</nav>

<div class="container" style="margin-top:20px">
