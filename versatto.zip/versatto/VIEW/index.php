<?php
session_start();
if (isset($_SESSION['login'])) {
    header("Location: /versatto/VIEW/home.php");
    exit;
}
$erro = $_SESSION['erro_login'] ?? '';
unset($_SESSION['erro_login']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Versatto - Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="/versatto/VIEW/css/style.css">
    <link rel="icon" href="/versatto/VIEW/images/logo.jpeg">
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">
        <img src="/versatto/VIEW/images/logo.jpeg" alt="Versatto">
        <h5 class="center" style="color:#1a3a6b;margin-bottom:20px">Controle de Acesso</h5>

        <?php if ($erro): ?>
        <div class="alerta-erro"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>

        <form action="/versatto/VIEW/login.php" method="POST" onsubmit="return validarLogin()">
            <div class="input-field">
                <i class="material-icons prefix" style="color:#1a3a6b">account_circle</i>
                <input id="usuario" type="text" name="usuario" required maxlength="40">
                <label for="usuario">Usuário</label>
                <span class="helper-text" data-error="Informe o usuário"></span>
            </div>
            <div class="input-field">
                <i class="material-icons prefix" style="color:#1a3a6b">lock</i>
                <input id="senha" type="password" name="senha" required>
                <label for="senha">Senha</label>
                <span class="helper-text" data-error="Informe a senha"></span>
            </div>
            <div class="center" style="margin-top:24px">
                <button class="btn btn-versatto waves-effect waves-light" type="submit" style="width:100%">
                    <i class="material-icons left">login</i>Entrar
                </button>
            </div>
        </form>
        <p class="center grey-text" style="margin-top:16px;font-size:.8rem">Versatto Móveis Planejados &copy; <?php echo date('Y'); ?></p>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="/versatto/VIEW/js/app.js"></script>
<script>
function validarLogin() {
    const u = document.getElementById('usuario');
    const s = document.getElementById('senha');
    let ok = true;
    if (u.value.trim() === '') { mostrarErro(u, 'Informe o usuário'); ok = false; }
    if (s.value.trim() === '') { mostrarErro(s, 'Informe a senha');   ok = false; }
    return ok;
}
</script>
</body>
</html>
