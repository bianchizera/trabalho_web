<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/venda.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
$id   = (int)($_GET['id'] ?? 0);
$dal  = new DAL\Venda();
$v    = $dal->selectById($id);
if (!$v) { header("Location: lstvenda.php"); exit; }
$cli   = (new DAL\Cliente())->selectById($v->getCliente());
$itens = $dal->selectItens($id);
$pmap  = []; foreach ((new DAL\Produto())->select() as $p) $pmap[$p->getId()] = $p->getDescricao();
?>
<div class="page-title"><i class="material-icons left">receipt</i>Detalhes da Venda #<?php echo $v->getId(); ?></div>
<div class="card-versatto">
    <div class="row">
        <div class="col s12 m6"><strong>Cliente:</strong> <?php echo htmlspecialchars($cli?->getNome() ?? '-'); ?></div>
        <div class="col s12 m3"><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($v->getDataVenda())); ?></div>
        <div class="col s12 m3"><strong>Total:</strong> R$ <?php echo number_format($v->getTotal(),2,',','.'); ?></div>
    </div>
    <?php if ($v->getObservacao()): ?><p><strong>Obs:</strong> <?php echo htmlspecialchars($v->getObservacao()); ?></p><?php endif; ?>
</div>
<div class="card-versatto" style="padding:0">
    <table class="versatto-table">
        <thead><tr><th>Produto</th><th class="right-align">Qtd</th><th class="right-align">Preço Venda</th><th class="right-align">Subtotal</th></tr></thead>
        <tbody>
        <?php foreach ($itens as $i): ?>
            <tr>
                <td><?php echo htmlspecialchars($pmap[$i->getProduto()] ?? '#'.$i->getProduto()); ?></td>
                <td class="right-align"><?php echo $i->getQuantidade(); ?></td>
                <td class="right-align">R$ <?php echo number_format($i->getPrecoVenda(),2,',','.'); ?></td>
                <td class="right-align">R$ <?php echo number_format($i->getSubtotal(),2,',','.'); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<a href="lstvenda.php" class="btn grey waves-effect"><i class="material-icons left">arrow_back</i>Voltar</a>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
