<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }

if (isset($_GET['acao']) && $_GET['acao'] === 'remover' && isset($_GET['id'])) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/venda.php';
    (new DAL\Venda())->delete((int)$_GET['id']);
    $_SESSION['msg'] = 'Venda excluída.';
    header("Location: lstvenda.php"); exit;
}

include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/venda.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$dal   = new DAL\Venda();
$lista = $dal->select();
$cmap  = [];
foreach ((new DAL\Cliente())->select() as $c) $cmap[$c->getId()] = $c->getNome();
$msg   = $_SESSION['msg'] ?? ''; unset($_SESSION['msg']);
?>
<div class="page-title"><i class="material-icons left">point_of_sale</i>Vendas</div>
<?php if ($msg): ?><div class="alerta-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="card-versatto"><div class="right-align">
    <a href="frmins.php" class="btn btn-amarelo waves-effect"><i class="material-icons left">add</i>Nova Venda</a>
</div></div>
<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table responsive-table">
        <thead><tr><th>#</th><th>Cliente</th><th>Data</th><th class="right-align">Total (R$)</th><th>Observação</th><th class="center">Ações</th></tr></thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="6" class="center grey-text">Nenhuma venda registrada.</td></tr>
        <?php else: foreach ($lista as $v): ?>
            <tr>
                <td><?php echo $v->getId(); ?></td>
                <td><?php echo htmlspecialchars($cmap[$v->getCliente()] ?? '-'); ?></td>
                <td><?php echo date('d/m/Y', strtotime($v->getDataVenda())); ?></td>
                <td class="right-align">R$ <?php echo number_format($v->getTotal(), 2, ',', '.'); ?></td>
                <td><?php echo htmlspecialchars($v->getObservacao()); ?></td>
                <td class="center" style="white-space:nowrap">
                    <a class="btn-floating btn-small waves-effect blue tooltipped" data-tooltip="Detalhes"
                       onclick="location.href='frmdet.php?id=<?php echo $v->getId(); ?>'"><i class="material-icons">info</i></a>
                    <a class="btn-floating btn-small waves-effect red tooltipped" data-tooltip="Excluir"
                       onclick="confirmarRemocao(<?php echo $v->getId(); ?>,'venda')"><i class="material-icons">delete</i></a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
