<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/venda.php';

$itensArr = json_decode($_POST['itens_json'] ?? '[]', true);
if (empty($itensArr)) { $_SESSION['msg'] = 'Nenhum item.'; header("Location: frmins.php"); exit; }

$venda = new \MODEL\Venda();
$venda->setCliente((int)$_POST['cliente']);
$venda->setDataVenda($_POST['data_venda']);
$venda->setTotal((float)$_POST['total']);
$venda->setObservacao(trim($_POST['observacao'] ?? ''));

$itens = [];
foreach ($itensArr as $i) {
    $item = new \MODEL\Itemvenda();
    $item->setProduto((int)$i['prodId']);
    $item->setQuantidade((float)$i['qtd']);
    $item->setPrecoVenda((float)$i['preco']);
    $item->setSubtotal((float)$i['subtotal']);
    $itens[] = $item;
}

$res = (new DAL\Venda())->inserirComItens($venda, $itens);
$_SESSION['msg'] = ($res === 'ok') ? 'Venda registrada! Estoque atualizado.' : $res;
header("Location: " . ($res === 'ok' ? "lstvenda.php" : "frmins.php")); exit;
