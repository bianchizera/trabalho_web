<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
$clientes = (new DAL\Cliente())->select();
$produtos  = (new DAL\Produto())->select();
?>
<div class="page-title"><i class="material-icons left">point_of_sale</i>Nova Venda</div>
<div class="card-versatto">
    <form method="POST" action="opins.php" id="frmVenda" onsubmit="return validarVenda()">

        <div class="row">
            <div class="input-field col s12 m5">
                <select id="cliente" name="cliente" required>
                    <option value="" disabled selected>Selecione o cliente...</option>
                    <?php foreach ($clientes as $c): ?>
                    <option value="<?php echo $c->getId(); ?>"><?php echo htmlspecialchars($c->getNome()); ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Cliente *</label>
            </div>
            <div class="input-field col s12 m3">
                <input id="data_venda" name="data_venda" type="date" required value="<?php echo date('Y-m-d'); ?>">
                <label for="data_venda" class="active">Data da Venda *</label>
            </div>
            <div class="input-field col s12 m4">
                <input id="observacao" name="observacao" type="text" maxlength="200">
                <label for="observacao">Observação</label>
            </div>
        </div>

        <div class="card-versatto" style="background:#fff9e0;border-top:3px solid #f5c842">
            <h6 style="color:#1a3a6b;font-weight:bold"><i class="material-icons left">add_circle</i>Adicionar Item</h6>
            <div class="row valign-wrapper" style="margin-bottom:0">
                <div class="input-field col s12 m5">
                    <select id="sel_produto">
                        <option value="" disabled selected>Selecione o produto...</option>
                        <?php foreach ($produtos as $p): ?>
                        <option value="<?php echo $p->getId(); ?>"
                                data-preco="<?php echo $p->getPrecoVenda(); ?>"
                                data-estoque="<?php echo $p->getEstoque(); ?>">
                            <?php echo htmlspecialchars($p->getDescricao()); ?>
                            (Estoque: <?php echo number_format($p->getEstoque(),2,',','.'); ?>
                             | R$ <?php echo number_format($p->getPrecoVenda(),2,',','.'); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <label>Produto</label>
                </div>
                <div class="input-field col s12 m2">
                    <input id="item_qtd" type="number" step="0.01" min="0.01" placeholder="Qtd">
                    <label for="item_qtd" class="active">Quantidade</label>
                </div>
                <div class="input-field col s12 m3">
                    <input id="item_preco" type="number" step="0.01" min="0.01" placeholder="0.00" readonly>
                    <label for="item_preco" class="active">Preço Venda (R$)</label>
                </div>
                <div class="col s12 m2">
                    <a class="btn btn-amarelo waves-effect" onclick="adicionarItemVenda()">
                        <i class="material-icons left">add</i>Adicionar
                    </a>
                </div>
            </div>
        </div>

        <div id="tabela-itens">
            <table class="versatto-table" id="tabela-itens-table" style="display:none">
                <thead><tr><th>Produto</th><th>Qtd</th><th>Preço Venda</th><th>Subtotal</th><th></th></tr></thead>
                <tbody id="itens-body"></tbody>
            </table>
        </div>
        <div class="total-box" style="margin-top:12px">Total: <strong id="total-valor">R$ 0.00</strong></div>

        <input type="hidden" name="total"       id="campo_total" value="0">
        <input type="hidden" name="itens_json"  id="campo_itens" value="[]">

        <div class="row" style="margin-top:16px"><div class="col s12">
            <button class="btn btn-versatto waves-effect btn-large" type="submit">
                <i class="material-icons left">save</i>Finalizar Venda
            </button>
            <a href="lstvenda.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
        </div></div>
    </form>
</div>

<script>
document.getElementById('sel_produto').addEventListener('change', function() {
    const opt = this.options[this.selectedIndex];
    document.getElementById('item_preco').value = opt.dataset.preco || '';
    M.updateTextFields();
});

// Versão da venda verifica estoque
function adicionarItemVenda() {
    const selProd = document.getElementById('sel_produto');
    const qtdEl   = document.getElementById('item_qtd');
    const precoEl = document.getElementById('item_preco');
    const prodId   = selProd.value;
    const opt      = selProd.options[selProd.selectedIndex];
    const prodDesc = opt?.text || '';
    const qtd      = parseFloat(qtdEl.value);
    const preco    = parseFloat(precoEl.value);
    const estoque  = parseFloat(opt?.dataset.estoque || 0);

    if (!prodId)             { M.toast({html:'Selecione um produto', classes:'red'}); return; }
    if (isNaN(qtd)||qtd<=0) { M.toast({html:'Quantidade inválida', classes:'red'}); return; }
    if (qtd > estoque)       { M.toast({html:'Estoque insuficiente! Disponível: '+estoque, classes:'red'}); return; }

    const idx = itens.findIndex(i => i.prodId == prodId);
    if (idx >= 0) {
        const novaQtd = itens[idx].qtd + qtd;
        if (novaQtd > estoque) { M.toast({html:'Estoque insuficiente!', classes:'red'}); return; }
        itens[idx].qtd = novaQtd; itens[idx].subtotal = novaQtd * itens[idx].preco;
    } else { itens.push({ prodId, prodDesc, qtd, preco, subtotal: qtd * preco }); }

    renderItens();
    qtdEl.value = ''; selProd.value = ''; document.getElementById('item_preco').value = '';
    M.FormSelect.init(selProd); M.updateTextFields();
}

const origRender = renderItens;
renderItens = function() {
    origRender();
    const tbl = document.getElementById('tabela-itens-table');
    if (tbl) tbl.style.display = itens.length > 0 ? 'table' : 'none';
};

function validarVenda() {
    if (!document.getElementById('cliente').value) { M.toast({html:'Selecione o cliente', classes:'red'}); return false; }
    if (!document.getElementById('data_venda').value) { M.toast({html:'Informe a data', classes:'red'}); return false; }
    if (itens.length === 0) { M.toast({html:'Adicione ao menos um item', classes:'red'}); return false; }
    return true;
}
</script>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
