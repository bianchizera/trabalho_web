<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$o = new \MODEL\Cliente();
$o->setNome(trim($_POST['nome']));
$o->setCpf(trim($_POST['cpf']));
$o->setEmail(trim($_POST['email']));
$o->setTelefone(trim($_POST['telefone']));
$o->setCidade(trim($_POST['cidade']));
$o->setEstado(strtoupper(trim($_POST['estado'])));
$o->setEndereco(trim($_POST['endereco']));

$dal = new DAL\Cliente();
if ($dal->insert($o)) {
    $_SESSION['msg'] = 'Cliente cadastrado com sucesso!';
} else {
    $_SESSION['msg'] = 'Erro ao cadastrar cliente.';
}
header("Location: lstcliente.php");
exit;
