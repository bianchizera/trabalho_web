<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }

// Ação remover ANTES de qualquer output
if (isset($_GET['acao']) && $_GET['acao'] === 'remover' && isset($_GET['id'])) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';
    (new DAL\Cliente())->delete((int)$_GET['id']);
    $_SESSION['msg'] = 'Cliente excluído com sucesso.';
    header("Location: lstcliente.php"); exit;
}

include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$dal   = new DAL\Cliente();
$busca = trim($_GET['busca'] ?? '');
$lista = $busca !== '' ? $dal->selectByNome($busca) : $dal->select();
$msg   = $_SESSION['msg'] ?? ''; unset($_SESSION['msg']);
?>

<div class="page-title"><i class="material-icons left">people</i>Clientes</div>
<?php if ($msg): ?><div class="alerta-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

<div class="card-versatto">
    <div class="row valign-wrapper" style="margin-bottom:0">
        <div class="col s12 m6">
            <form method="GET">
                <div class="input-field inline" style="width:260px">
                    <input type="text" name="busca" id="busca" value="<?php echo htmlspecialchars($busca); ?>" placeholder="Buscar por nome...">
                    <label for="busca">Buscar</label>
                </div>
                <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons">search</i></button>
                <?php if ($busca): ?><a href="lstcliente.php" class="btn grey waves-effect" style="margin-left:6px">Limpar</a><?php endif; ?>
            </form>
        </div>
        <div class="col s12 m6 right-align">
            <a href="frminscliente.php" class="btn btn-amarelo waves-effect"><i class="material-icons left">add</i>Novo Cliente</a>
            <a href="/versatto/VIEW/RELATORIO/relcliente.php" class="btn red waves-effect" style="margin-left:6px"><i class="material-icons left">picture_as_pdf</i>PDF</a>
        </div>
    </div>
</div>

<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table responsive-table">
        <thead>
            <tr><th>#</th><th>Nome</th><th>CPF</th><th>E-mail</th><th>Telefone</th><th>Cidade/UF</th><th class="center">Ações</th></tr>
        </thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="7" class="center grey-text">Nenhum cliente encontrado.</td></tr>
        <?php else: foreach ($lista as $c): ?>
            <tr>
                <td><?php echo $c->getId(); ?></td>
                <td><?php echo htmlspecialchars($c->getNome()); ?></td>
                <td><?php echo htmlspecialchars($c->getCpf()); ?></td>
                <td><?php echo htmlspecialchars($c->getEmail()); ?></td>
                <td><?php echo htmlspecialchars($c->getTelefone()); ?></td>
                <td><?php echo htmlspecialchars($c->getCidade()) . '/' . htmlspecialchars($c->getEstado()); ?></td>
                <td class="center" style="white-space:nowrap">
                    <a class="btn-floating btn-small waves-effect blue tooltipped" data-tooltip="Detalhes"
                       onclick="location.href='frmdetcliente.php?id=<?php echo $c->getId(); ?>'"><i class="material-icons">info</i></a>
                    <a class="btn-floating btn-small waves-effect orange tooltipped" data-tooltip="Editar"
                       onclick="location.href='frmedtcliente.php?id=<?php echo $c->getId(); ?>'"><i class="material-icons">edit</i></a>
                    <a class="btn-floating btn-small waves-effect red tooltipped" data-tooltip="Excluir"
                       onclick="confirmarRemocao(<?php echo $c->getId(); ?>,'cliente')"><i class="material-icons">delete</i></a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
