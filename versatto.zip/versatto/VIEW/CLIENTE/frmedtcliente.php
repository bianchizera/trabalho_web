<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$id  = (int)($_GET['id'] ?? 0);
$dal = new DAL\Cliente();
$c   = $dal->selectById($id);
if (!$c) { header("Location: lstcliente.php"); exit; }
?>

<div class="page-title"><i class="material-icons left">edit</i>Editar Cliente</div>

<div class="card-versatto">
    <form method="POST" action="opedtcliente.php" onsubmit="return validarFormCliente()">
        <input type="hidden" name="id" value="<?php echo $c->getId(); ?>">
        <div class="row">
            <div class="input-field col s12 m8">
                <i class="material-icons prefix">person</i>
                <input id="nome" name="nome" type="text" maxlength="80" value="<?php echo htmlspecialchars($c->getNome()); ?>" required>
                <label for="nome" class="active">Nome completo *</label>
                <span class="helper-text" data-error="Nome obrigatório"></span>
            </div>
            <div class="input-field col s12 m4">
                <i class="material-icons prefix">badge</i>
                <input id="cpf" name="cpf" type="text" maxlength="14" value="<?php echo htmlspecialchars($c->getCpf()); ?>" required
                       oninput="this.value=mascaraCPF(this.value)">
                <label for="cpf" class="active">CPF *</label>
                <span class="helper-text" data-error="CPF inválido"></span>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m6">
                <i class="material-icons prefix">email</i>
                <input id="email" name="email" type="email" maxlength="80" value="<?php echo htmlspecialchars($c->getEmail()); ?>" required>
                <label for="email" class="active">E-mail *</label>
                <span class="helper-text" data-error="E-mail inválido"></span>
            </div>
            <div class="input-field col s12 m6">
                <i class="material-icons prefix">phone</i>
                <input id="telefone" name="telefone" type="text" maxlength="15" value="<?php echo htmlspecialchars($c->getTelefone()); ?>" required
                       oninput="this.value=mascaraTelefone(this.value)">
                <label for="telefone" class="active">Telefone *</label>
                <span class="helper-text" data-error="Telefone inválido"></span>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m6">
                <i class="material-icons prefix">location_city</i>
                <input id="cidade" name="cidade" type="text" maxlength="50" value="<?php echo htmlspecialchars($c->getCidade()); ?>" required>
                <label for="cidade" class="active">Cidade *</label>
                <span class="helper-text" data-error="Cidade obrigatória"></span>
            </div>
            <div class="input-field col s12 m2">
                <i class="material-icons prefix">map</i>
                <input id="estado" name="estado" type="text" maxlength="2" value="<?php echo htmlspecialchars($c->getEstado()); ?>" required>
                <label for="estado" class="active">UF *</label>
            </div>
            <div class="input-field col s12 m4">
                <i class="material-icons prefix">home</i>
                <input id="endereco" name="endereco" type="text" maxlength="100" value="<?php echo htmlspecialchars($c->getEndereco()); ?>" required>
                <label for="endereco" class="active">Endereço *</label>
                <span class="helper-text" data-error="Endereço obrigatório"></span>
            </div>
        </div>
        <div class="row">
            <div class="col s12">
                <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
                <a href="lstcliente.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
            </div>
        </div>
    </form>
</div>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
