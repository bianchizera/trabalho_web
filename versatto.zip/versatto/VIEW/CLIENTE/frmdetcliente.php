<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$id  = (int)($_GET['id'] ?? 0);
$dal = new DAL\Cliente();
$c   = $dal->selectById($id);
if (!$c) { header("Location: lstcliente.php"); exit; }
?>

<div class="page-title"><i class="material-icons left">info</i>Detalhes do Cliente</div>

<div class="card-versatto">
    <table class="versatto-table">
        <tbody>
            <tr><th style="width:200px;background:#eceff1;color:#1a3a6b">Código</th><td><?php echo $c->getId(); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Nome</th><td><?php echo htmlspecialchars($c->getNome()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">CPF</th><td><?php echo htmlspecialchars($c->getCpf()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">E-mail</th><td><?php echo htmlspecialchars($c->getEmail()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Telefone</th><td><?php echo htmlspecialchars($c->getTelefone()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Cidade/UF</th><td><?php echo htmlspecialchars($c->getCidade()) . ' / ' . htmlspecialchars($c->getEstado()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Endereço</th><td><?php echo htmlspecialchars($c->getEndereco()); ?></td></tr>
        </tbody>
    </table>
    <div style="margin-top:16px">
        <a href="frmedtcliente.php?id=<?php echo $c->getId(); ?>" class="btn btn-amarelo waves-effect"><i class="material-icons left">edit</i>Editar</a>
        <a href="lstcliente.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
    </div>
</div>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
