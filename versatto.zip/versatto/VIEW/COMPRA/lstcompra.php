<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }

if (isset($_GET['acao']) && $_GET['acao'] === 'remover' && isset($_GET['id'])) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/compra.php';
    (new DAL\Compra())->delete((int)$_GET['id']);
    $_SESSION['msg'] = 'Compra excluída.';
    header("Location: lstcompra.php"); exit;
}

include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/compra.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';

$dal   = new DAL\Compra();
$lista = $dal->select();
$fmap  = [];
foreach ((new DAL\Fornecedor())->select() as $f) $fmap[$f->getId()] = $f->getRazao();
$msg   = $_SESSION['msg'] ?? ''; unset($_SESSION['msg']);
?>
<div class="page-title"><i class="material-icons left">add_shopping_cart</i>Compras</div>
<?php if ($msg): ?><div class="alerta-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="card-versatto"><div class="right-align">
    <a href="frmins.php" class="btn btn-amarelo waves-effect"><i class="material-icons left">add</i>Nova Compra</a>
</div></div>
<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table responsive-table">
        <thead><tr><th>#</th><th>Fornecedor</th><th>Data</th><th class="right-align">Total (R$)</th><th>Observação</th><th class="center">Ações</th></tr></thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="6" class="center grey-text">Nenhuma compra registrada.</td></tr>
        <?php else: foreach ($lista as $c): ?>
            <tr>
                <td><?php echo $c->getId(); ?></td>
                <td><?php echo htmlspecialchars($fmap[$c->getFornecedor()] ?? '-'); ?></td>
                <td><?php echo date('d/m/Y', strtotime($c->getDataCompra())); ?></td>
                <td class="right-align">R$ <?php echo number_format($c->getTotal(), 2, ',', '.'); ?></td>
                <td><?php echo htmlspecialchars($c->getObservacao()); ?></td>
                <td class="center" style="white-space:nowrap">
                    <a class="btn-floating btn-small waves-effect blue tooltipped" data-tooltip="Ver itens"
                       onclick="location.href='frmdet.php?id=<?php echo $c->getId(); ?>'"><i class="material-icons">info</i></a>
                    <a class="btn-floating btn-small waves-effect red tooltipped" data-tooltip="Excluir"
                       onclick="confirmarRemocao(<?php echo $c->getId(); ?>,'compra')"><i class="material-icons">delete</i></a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
