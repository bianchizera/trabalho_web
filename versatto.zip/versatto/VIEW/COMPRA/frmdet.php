<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/compra.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
$id   = (int)($_GET['id'] ?? 0);
$dal  = new DAL\Compra();
$c    = $dal->selectById($id);
if (!$c) { header("Location: lstcompra.php"); exit; }
$forn  = (new DAL\Fornecedor())->selectById($c->getFornecedor());
$itens = $dal->selectItens($id);
?>
<div class="page-title"><i class="material-icons left">receipt</i>Detalhes da Compra #<?php echo $c->getId(); ?></div>
<div class="card-versatto">
    <div class="row">
        <div class="col s12 m6"><strong>Fornecedor:</strong> <?php echo htmlspecialchars($forn?->getRazao() ?? '-'); ?></div>
        <div class="col s12 m3"><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($c->getDataCompra())); ?></div>
        <div class="col s12 m3"><strong>Total:</strong> R$ <?php echo number_format($c->getTotal(),2,',','.'); ?></div>
    </div>
    <?php if ($c->getObservacao()): ?><p><strong>Obs:</strong> <?php echo htmlspecialchars($c->getObservacao()); ?></p><?php endif; ?>
</div>
<div class="card-versatto" style="padding:0">
    <table class="versatto-table">
        <thead><tr><th>Produto</th><th class="right-align">Qtd</th><th class="right-align">Preço Compra</th><th class="right-align">Subtotal</th></tr></thead>
        <tbody>
        <?php foreach ($itens as $i): ?>
            <tr>
                <td><?php echo $i->getProduto(); ?></td>
                <td class="right-align"><?php echo $i->getQuantidade(); ?></td>
                <td class="right-align">R$ <?php echo number_format($i->getPrecoCompra(),2,',','.'); ?></td>
                <td class="right-align">R$ <?php echo number_format($i->getSubtotal(),2,',','.'); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<a href="lstcompra.php" class="btn grey waves-effect"><i class="material-icons left">arrow_back</i>Voltar</a>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
