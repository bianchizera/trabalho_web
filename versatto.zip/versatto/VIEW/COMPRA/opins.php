<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/compra.php';

$itensJson = $_POST['itens_json'] ?? '[]';
$itensArr  = json_decode($itensJson, true);

if (empty($itensArr)) {
    $_SESSION['msg'] = 'Nenhum item adicionado.';
    header("Location: frmins.php"); exit;
}

$compra = new \MODEL\Compra();
$compra->setFornecedor((int)$_POST['fornecedor']);
$compra->setDataCompra($_POST['data_compra']);
$compra->setTotal((float)$_POST['total']);
$compra->setObservacao(trim($_POST['observacao'] ?? ''));

$itens = [];
foreach ($itensArr as $i) {
    $item = new \MODEL\Itemcompra();
    $item->setProduto((int)$i['prodId']);
    $item->setQuantidade((float)$i['qtd']);
    $item->setPrecoCompra((float)$i['preco']);
    $item->setSubtotal((float)$i['subtotal']);
    $itens[] = $item;
}

$dal = new DAL\Compra();
if ($dal->inserirComItens($compra, $itens)) {
    $_SESSION['msg'] = 'Compra registrada! Estoque e preços atualizados.';
    header("Location: lstcompra.php");
} else {
    $_SESSION['msg'] = 'Erro ao registrar compra.';
    header("Location: frmins.php");
}
exit;
