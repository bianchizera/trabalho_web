<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
$fornecedores = (new DAL\Fornecedor())->select();
$produtos     = (new DAL\Produto())->select();
?>
<div class="page-title"><i class="material-icons left">add_shopping_cart</i>Nova Compra</div>
<div class="card-versatto">
    <form method="POST" action="opins.php" id="frmCompra" onsubmit="return validarCompra()">

        <div class="row">
            <div class="input-field col s12 m5">
                <select id="fornecedor" name="fornecedor" required>
                    <option value="" disabled selected>Selecione o fornecedor...</option>
                    <?php foreach ($fornecedores as $f): ?>
                    <option value="<?php echo $f->getId(); ?>"><?php echo htmlspecialchars($f->getRazao()); ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Fornecedor *</label>
            </div>
            <div class="input-field col s12 m3">
                <input id="data_compra" name="data_compra" type="date" required value="<?php echo date('Y-m-d'); ?>">
                <label for="data_compra" class="active">Data da Compra *</label>
            </div>
            <div class="input-field col s12 m4">
                <input id="observacao" name="observacao" type="text" maxlength="200">
                <label for="observacao">Observação</label>
            </div>
        </div>

        <div class="card-versatto" style="background:#fff9e0;border-top:3px solid #f5c842">
            <h6 style="color:#1a3a6b;font-weight:bold"><i class="material-icons left">add_circle</i>Adicionar Item</h6>
            <div class="row valign-wrapper" style="margin-bottom:0">
                <div class="input-field col s12 m5">
                    <select id="sel_produto">
                        <option value="" disabled selected>Selecione o produto...</option>
                        <?php foreach ($produtos as $p): ?>
                        <option value="<?php echo $p->getId(); ?>"
                                data-preco="<?php echo $p->getPrecoCompra(); ?>">
                            <?php echo htmlspecialchars($p->getDescricao()); ?> (Estoque: <?php echo $p->getEstoque(); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <label>Produto</label>
                </div>
                <div class="input-field col s12 m2">
                    <input id="item_qtd" type="number" step="0.01" min="0.01" placeholder="Qtd">
                    <label for="item_qtd" class="active">Quantidade</label>
                </div>
                <div class="input-field col s12 m3">
                    <input id="item_preco" type="number" step="0.01" min="0.01" placeholder="0.00">
                    <label for="item_preco" class="active">Preço Compra (R$)</label>
                </div>
                <div class="col s12 m2">
                    <a class="btn btn-amarelo waves-effect" onclick="adicionarItem()">
                        <i class="material-icons left">add</i>Adicionar
                    </a>
                </div>
            </div>
        </div>

        <div id="tabela-itens">
            <table class="versatto-table" id="tabela-itens-table" style="display:none">
                <thead><tr><th>Produto</th><th>Qtd</th><th>Preço Compra</th><th>Subtotal</th><th></th></tr></thead>
                <tbody id="itens-body"></tbody>
            </table>
        </div>

        <div class="total-box" style="margin-top:12px">
            Total: <strong id="total-valor">R$ 0.00</strong>
        </div>

        <input type="hidden" name="total"       id="campo_total" value="0">
        <input type="hidden" name="itens_json"  id="campo_itens" value="[]">

        <div class="row" style="margin-top:16px"><div class="col s12">
            <button class="btn btn-versatto waves-effect btn-large" type="submit">
                <i class="material-icons left">save</i>Finalizar Compra
            </button>
            <a href="lstcompra.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
        </div></div>
    </form>
</div>

<script>
// Preenche preço ao selecionar produto
document.getElementById('sel_produto').addEventListener('change', function() {
    const opt = this.options[this.selectedIndex];
    document.getElementById('item_preco').value = opt.dataset.preco || '';
    M.updateTextFields();
});

// Mostra tabela ao adicionar itens
const origRender = renderItens;
renderItens = function() {
    origRender();
    const tbl = document.getElementById('tabela-itens-table');
    if (tbl) tbl.style.display = itens.length > 0 ? 'table' : 'none';
};

function validarCompra() {
    const forn = document.getElementById('fornecedor').value;
    const data = document.getElementById('data_compra').value;
    if (!forn) { M.toast({html:'Selecione o fornecedor', classes:'red'}); return false; }
    if (!data)  { M.toast({html:'Informe a data', classes:'red'}); return false; }
    if (itens.length === 0) { M.toast({html:'Adicione ao menos um item', classes:'red'}); return false; }
    return true;
}
</script>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
