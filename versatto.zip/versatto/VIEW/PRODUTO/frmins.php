<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
$tipos       = (new DAL\Tipoproduto())->select();
$fornecedores = (new DAL\Fornecedor())->select();
?>
<div class="page-title"><i class="material-icons left">add</i>Novo Produto</div>
<div class="card-versatto">
    <form method="POST" action="opins.php" onsubmit="return validarFormProduto()">
        <div class="row">
            <div class="input-field col s12 m6">
                <input id="descricao" name="descricao" type="text" maxlength="100" required>
                <label for="descricao">Descrição *</label>
                <span class="helper-text" data-error="Obrigatório"></span>
            </div>
            <div class="input-field col s12 m3">
                <select id="tipoproduto" name="tipoproduto" required>
                    <option value="" disabled selected>Selecione...</option>
                    <?php foreach ($tipos as $t): ?>
                    <option value="<?php echo $t->getId(); ?>"><?php echo htmlspecialchars($t->getDescricao()); ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Tipo de Produto *</label>
            </div>
            <div class="input-field col s12 m3">
                <select id="fornecedor" name="fornecedor" required>
                    <option value="" disabled selected>Selecione...</option>
                    <?php foreach ($fornecedores as $f): ?>
                    <option value="<?php echo $f->getId(); ?>"><?php echo htmlspecialchars($f->getRazao()); ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Fornecedor *</label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m3">
                <input id="estoque" name="estoque" type="number" step="0.01" min="0" value="0" required>
                <label for="estoque" class="active">Estoque Inicial *</label>
                <span class="helper-text" data-error="Inválido"></span>
            </div>
            <div class="input-field col s12 m3">
                <input id="preco_compra" name="preco_compra" type="number" step="0.01" min="0.01" required
                       oninput="calcularPrecoVenda()">
                <label for="preco_compra">Preço de Compra (R$) *</label>
                <span class="helper-text" data-error="Inválido"></span>
            </div>
            <div class="input-field col s12 m3">
                <input id="preco_venda" name="preco_venda" type="number" step="0.01" min="0.01" required>
                <label for="preco_venda" class="active">Preço de Venda (R$) * <small style="color:#607d8b">(+20%)</small></label>
            </div>
            <div class="input-field col s12 m3">
                <select id="unidade" name="unidade">
                    <option value="un" selected>un</option>
                    <option value="m²">m²</option>
                    <option value="m">m</option>
                    <option value="cx">cx</option>
                    <option value="kg">kg</option>
                </select>
                <label>Unidade</label>
            </div>
        </div>
        <div class="row"><div class="col s12">
            <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
            <a href="lstproduto.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
        </div></div>
    </form>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>