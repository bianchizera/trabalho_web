<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
$o = new \MODEL\Produto();
$o->setDescricao(trim($_POST['descricao']));
$o->setTipoproduto((int)$_POST['tipoproduto']);
$o->setFornecedor((int)$_POST['fornecedor']);
$o->setEstoque((float)$_POST['estoque']);
$o->setPrecoCompra((float)$_POST['preco_compra']);
$o->setPrecoVenda((float)$_POST['preco_venda']);
$o->setUnidade($_POST['unidade']);
$_SESSION['msg'] = (new DAL\Produto())->insert($o) ? 'Produto cadastrado!' : 'Erro ao cadastrar.';
header("Location: lstproduto.php"); exit;