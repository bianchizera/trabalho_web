<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }

if (isset($_GET['acao']) && $_GET['acao'] === 'remover' && isset($_GET['id'])) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
    (new DAL\Produto())->delete((int)$_GET['id']);
    $_SESSION['msg'] = 'Produto excluído.';
    header("Location: lstproduto.php"); exit;
}

include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';

$dal   = new DAL\Produto();
$busca = trim($_GET['busca'] ?? '');
$lista = $busca !== '' ? $dal->selectByDescricao($busca) : $dal->select();
$msg   = $_SESSION['msg'] ?? ''; unset($_SESSION['msg']);
$tipos = [];
foreach ((new DAL\Tipoproduto())->select() as $t) $tipos[$t->getId()] = $t->getDescricao();
?>
<div class="page-title"><i class="material-icons left">inventory_2</i>Produtos</div>
<?php if ($msg): ?><div class="alerta-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="card-versatto">
    <div class="row valign-wrapper" style="margin-bottom:0">
        <div class="col s12 m6">
            <form method="GET">
                <div class="input-field inline" style="width:260px">
                    <input type="text" name="busca" id="busca" value="<?php echo htmlspecialchars($busca); ?>" placeholder="Buscar produto...">
                    <label for="busca">Buscar</label>
                </div>
                <button class="btn btn-versatto" type="submit"><i class="material-icons">search</i></button>
                <?php if ($busca): ?><a href="lstproduto.php" class="btn grey" style="margin-left:6px">Limpar</a><?php endif; ?>
            </form>
        </div>
        <div class="col s12 m6 right-align">
            <a href="frmins.php" class="btn btn-amarelo waves-effect"><i class="material-icons left">add</i>Novo Produto</a>
            <a href="/versatto/VIEW/RELATORIO/relestoque.php" class="btn red waves-effect" style="margin-left:6px"><i class="material-icons left">picture_as_pdf</i>Estoque PDF</a>
        </div>
    </div>
</div>
<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table responsive-table">
        <thead>
            <tr><th>#</th><th>Descrição</th><th>Tipo</th><th class="right-align">Estoque</th><th class="right-align">Preço Compra</th><th class="right-align">Preço Venda</th><th>Unid.</th><th class="center">Ações</th></tr>
        </thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="8" class="center grey-text">Nenhum produto encontrado.</td></tr>
        <?php else: foreach ($lista as $p): ?>
            <tr>
                <td><?php echo $p->getId(); ?></td>
                <td><?php echo htmlspecialchars($p->getDescricao()); ?></td>
                <td><?php echo htmlspecialchars($tipos[$p->getTipoproduto()] ?? '-'); ?></td>
                <td class="right-align <?php echo $p->getEstoque() <= 2 ? 'estoque-baixo' : ''; ?>">
                    <?php echo number_format($p->getEstoque(), 2, ',', '.'); ?>
                </td>
                <td class="right-align">R$ <?php echo number_format($p->getPrecoCompra(), 2, ',', '.'); ?></td>
                <td class="right-align">R$ <?php echo number_format($p->getPrecoVenda(), 2, ',', '.'); ?></td>
                <td><?php echo htmlspecialchars($p->getUnidade()); ?></td>
                <td class="center" style="white-space:nowrap">
                    <a class="btn-floating btn-small waves-effect blue tooltipped" data-tooltip="Detalhes"
                       onclick="location.href='frmdet.php?id=<?php echo $p->getId(); ?>'"><i class="material-icons">info</i></a>
                    <a class="btn-floating btn-small waves-effect orange tooltipped" data-tooltip="Editar"
                       onclick="location.href='frmedt.php?id=<?php echo $p->getId(); ?>'"><i class="material-icons">edit</i></a>
                    <a class="btn-floating btn-small waves-effect red tooltipped" data-tooltip="Excluir"
                       onclick="confirmarRemocao(<?php echo $p->getId(); ?>,'produto')"><i class="material-icons">delete</i></a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
