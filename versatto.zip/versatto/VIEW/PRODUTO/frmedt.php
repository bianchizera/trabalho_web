<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
$id = (int)($_GET['id'] ?? 0);
$p  = (new DAL\Produto())->selectById($id);
if (!$p) { header("Location: lstproduto.php"); exit; }
$tipos       = (new DAL\Tipoproduto())->select();
$fornecedores = (new DAL\Fornecedor())->select();
?>
<div class="page-title"><i class="material-icons left">edit</i>Editar Produto</div>
<div class="card-versatto">
    <form method="POST" action="opedt.php" onsubmit="return validarFormProduto()">
        <input type="hidden" name="id" value="<?php echo $p->getId(); ?>">
        <div class="row">
            <div class="input-field col s12 m6">
                <input id="descricao" name="descricao" type="text" maxlength="100" value="<?php echo htmlspecialchars($p->getDescricao()); ?>" required>
                <label for="descricao" class="active">Descrição *</label>
                <span class="helper-text" data-error="Obrigatório"></span>
            </div>
            <div class="input-field col s12 m3">
                <select id="tipoproduto" name="tipoproduto" required>
                    <?php foreach ($tipos as $t): ?>
                    <option value="<?php echo $t->getId(); ?>" <?php echo $t->getId()==$p->getTipoproduto()?'selected':''; ?>>
                        <?php echo htmlspecialchars($t->getDescricao()); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <label>Tipo de Produto *</label>
            </div>
            <div class="input-field col s12 m3">
                <select id="fornecedor" name="fornecedor" required>
                    <?php foreach ($fornecedores as $f): ?>
                    <option value="<?php echo $f->getId(); ?>" <?php echo $f->getId()==$p->getFornecedor()?'selected':''; ?>>
                        <?php echo htmlspecialchars($f->getRazao()); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <label>Fornecedor *</label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m3">
                <input id="estoque" name="estoque" type="number" step="0.01" min="0" value="<?php echo $p->getEstoque(); ?>" required>
                <label for="estoque" class="active">Estoque *</label>
                <span class="helper-text" data-error="Inválido"></span>
            </div>
            <div class="input-field col s12 m3">
                <input id="preco_compra" name="preco_compra" type="number" step="0.01" min="0.01" value="<?php echo $p->getPrecoCompra(); ?>" required oninput="calcularPrecoVenda()">
                <label for="preco_compra" class="active">Preço Compra (R$) *</label>
                <span class="helper-text" data-error="Inválido"></span>
            </div>
            <div class="input-field col s12 m3">
                <input id="preco_venda" name="preco_venda" type="number" step="0.01" min="0.01" value="<?php echo $p->getPrecoVenda(); ?>" required>
                <label for="preco_venda" class="active">Preço Venda (R$) *</label>
            </div>
            <div class="input-field col s12 m3">
                <select id="unidade" name="unidade">
                    <?php foreach (['un','m²','m','cx','kg'] as $u): ?>
                    <option value="<?php echo $u; ?>" <?php echo $u==$p->getUnidade()?'selected':''; ?>><?php echo $u; ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Unidade</label>
            </div>
        </div>
        <div class="row"><div class="col s12">
            <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
            <a href="lstproduto.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
        </div></div>
    </form>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>