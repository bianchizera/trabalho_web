<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
$id = (int)($_GET['id'] ?? 0);
$p  = (new DAL\Produto())->selectById($id);
if (!$p) { header("Location: lstproduto.php"); exit; }
$tipos = []; foreach ((new DAL\Tipoproduto())->select() as $t) $tipos[$t->getId()] = $t->getDescricao();
?>
<div class="page-title"><i class="material-icons left">info</i>Detalhes do Produto</div>
<div class="card-versatto">
    <table class="versatto-table">
        <tbody>
            <tr><th style="background:#eceff1;color:#1a3a6b;width:200px">Código</th><td><?php echo $p->getId(); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Descrição</th><td><?php echo htmlspecialchars($p->getDescricao()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Tipo</th><td><?php echo htmlspecialchars($tipos[$p->getTipoproduto()] ?? '-'); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Estoque</th><td><?php echo number_format($p->getEstoque(),2,',','.') . ' ' . $p->getUnidade(); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Preço Compra</th><td>R$ <?php echo number_format($p->getPrecoCompra(),2,',','.'); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Preço Venda</th><td>R$ <?php echo number_format($p->getPrecoVenda(),2,',','.'); ?></td></tr>
        </tbody>
    </table>
    <div style="margin-top:16px">
        <a href="frmedt.php?id=<?php echo $p->getId(); ?>" class="btn btn-amarelo waves-effect"><i class="material-icons left">edit</i>Editar</a>
        <a href="lstproduto.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
    </div>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
