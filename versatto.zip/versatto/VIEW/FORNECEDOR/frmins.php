<?php include_once dirname(__DIR__) . '/menu.php'; ?>
<div class="page-title"><i class="material-icons left">add_business</i>Novo Fornecedor</div>
<div class="card-versatto">
    <form method="POST" action="opins.php" onsubmit="return validarFormFornecedor()">
        <div class="row">
            <div class="input-field col s12 m8">
                <i class="material-icons prefix">business</i>
                <input id="razao" name="razao" type="text" maxlength="100" required>
                <label for="razao">Razão Social *</label>
                <span class="helper-text" data-error="Obrigatório"></span>
            </div>
            <div class="input-field col s12 m4">
                <i class="material-icons prefix">badge</i>
                <input id="cnpj" name="cnpj" type="text" maxlength="18" required oninput="this.value=mascaraCNPJ(this.value)">
                <label for="cnpj">CNPJ *</label>
                <span class="helper-text" data-error="CNPJ inválido"></span>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m6">
                <i class="material-icons prefix">email</i>
                <input id="email" name="email" type="email" maxlength="80" required>
                <label for="email">E-mail *</label>
                <span class="helper-text" data-error="E-mail inválido"></span>
            </div>
            <div class="input-field col s12 m6">
                <i class="material-icons prefix">phone</i>
                <input id="telefone" name="telefone" type="text" maxlength="15" required oninput="this.value=mascaraTelefone(this.value)">
                <label for="telefone">Telefone *</label>
                <span class="helper-text" data-error="Inválido"></span>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m6">
                <i class="material-icons prefix">location_city</i>
                <input id="cidade" name="cidade" type="text" maxlength="50" required>
                <label for="cidade">Cidade *</label>
            </div>
            <div class="input-field col s12 m2">
                <input id="estado" name="estado" type="text" maxlength="2" value="SP" required>
                <label for="estado" class="active">UF</label>
            </div>
            <div class="input-field col s12 m4">
                <i class="material-icons prefix">person</i>
                <input id="contato" name="contato" type="text" maxlength="60" required>
                <label for="contato">Nome do Contato *</label>
            </div>
        </div>
        <div class="row"><div class="col s12">
            <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
            <a href="lstfornecedor.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
        </div></div>
    </form>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
