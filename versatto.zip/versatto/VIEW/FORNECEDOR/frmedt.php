<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
$id = (int)($_GET['id'] ?? 0);
$f  = (new DAL\Fornecedor())->selectById($id);
if (!$f) { header("Location: lstfornecedor.php"); exit; }
?>
<div class="page-title"><i class="material-icons left">edit</i>Editar Fornecedor</div>
<div class="card-versatto">
    <form method="POST" action="opedt.php" onsubmit="return validarFormFornecedor()">
        <input type="hidden" name="id" value="<?php echo $f->getId(); ?>">
        <div class="row">
            <div class="input-field col s12 m8">
                <input id="razao" name="razao" type="text" value="<?php echo htmlspecialchars($f->getRazao()); ?>" required>
                <label for="razao" class="active">Razão Social *</label>
                <span class="helper-text" data-error="Obrigatório"></span>
            </div>
            <div class="input-field col s12 m4">
                <input id="cnpj" name="cnpj" type="text" value="<?php echo htmlspecialchars($f->getCnpj()); ?>" required oninput="this.value=mascaraCNPJ(this.value)">
                <label for="cnpj" class="active">CNPJ *</label>
                <span class="helper-text" data-error="CNPJ inválido"></span>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m6">
                <input id="email" name="email" type="email" value="<?php echo htmlspecialchars($f->getEmail()); ?>" required>
                <label for="email" class="active">E-mail *</label>
                <span class="helper-text" data-error="E-mail inválido"></span>
            </div>
            <div class="input-field col s12 m6">
                <input id="telefone" name="telefone" type="text" value="<?php echo htmlspecialchars($f->getTelefone()); ?>" required oninput="this.value=mascaraTelefone(this.value)">
                <label for="telefone" class="active">Telefone *</label>
                <span class="helper-text" data-error="Inválido"></span>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12 m6">
                <input id="cidade" name="cidade" type="text" value="<?php echo htmlspecialchars($f->getCidade()); ?>" required>
                <label for="cidade" class="active">Cidade *</label>
            </div>
            <div class="input-field col s12 m2">
                <input id="estado" name="estado" type="text" maxlength="2" value="<?php echo htmlspecialchars($f->getEstado()); ?>" required>
                <label for="estado" class="active">UF</label>
            </div>
            <div class="input-field col s12 m4">
                <input id="contato" name="contato" type="text" value="<?php echo htmlspecialchars($f->getContato()); ?>" required>
                <label for="contato" class="active">Contato *</label>
            </div>
        </div>
        <div class="row"><div class="col s12">
            <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
            <a href="lstfornecedor.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
        </div></div>
    </form>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
