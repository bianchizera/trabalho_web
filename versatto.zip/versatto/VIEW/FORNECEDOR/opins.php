<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
$o = new \MODEL\Fornecedor();
$o->setRazao(trim($_POST['razao']));
$o->setCnpj(trim($_POST['cnpj']));
$o->setEmail(trim($_POST['email']));
$o->setTelefone(trim($_POST['telefone']));
$o->setCidade(trim($_POST['cidade']));
$o->setEstado(strtoupper(trim($_POST['estado'])));
$o->setContato(trim($_POST['contato']));
$dal = new DAL\Fornecedor();
$_SESSION['msg'] = $dal->insert($o) ? 'Fornecedor cadastrado!' : 'Erro ao cadastrar.';
header("Location: lstfornecedor.php"); exit;
