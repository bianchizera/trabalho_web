<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
$id = (int)($_GET['id'] ?? 0);
$f  = (new DAL\Fornecedor())->selectById($id);
if (!$f) { header("Location: lstfornecedor.php"); exit; }
?>
<div class="page-title"><i class="material-icons left">info</i>Detalhes do Fornecedor</div>
<div class="card-versatto">
    <table class="versatto-table">
        <tbody>
            <tr><th style="background:#eceff1;color:#1a3a6b;width:200px">Código</th><td><?php echo $f->getId(); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Razão Social</th><td><?php echo htmlspecialchars($f->getRazao()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">CNPJ</th><td><?php echo htmlspecialchars($f->getCnpj()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">E-mail</th><td><?php echo htmlspecialchars($f->getEmail()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Telefone</th><td><?php echo htmlspecialchars($f->getTelefone()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Cidade/UF</th><td><?php echo htmlspecialchars($f->getCidade()) . ' / ' . htmlspecialchars($f->getEstado()); ?></td></tr>
            <tr><th style="background:#eceff1;color:#1a3a6b">Contato</th><td><?php echo htmlspecialchars($f->getContato()); ?></td></tr>
        </tbody>
    </table>
    <div style="margin-top:16px">
        <a href="frmedt.php?id=<?php echo $f->getId(); ?>" class="btn btn-amarelo waves-effect"><i class="material-icons left">edit</i>Editar</a>
        <a href="lstfornecedor.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
    </div>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
