<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }

if (isset($_GET['acao']) && $_GET['acao'] === 'remover' && isset($_GET['id'])) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';
    (new DAL\Fornecedor())->delete((int)$_GET['id']);
    $_SESSION['msg'] = 'Fornecedor excluído.';
    header("Location: lstfornecedor.php"); exit;
}

include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';

$dal   = new DAL\Fornecedor();
$lista = $dal->select();
$msg   = $_SESSION['msg'] ?? ''; unset($_SESSION['msg']);
?>
<div class="page-title"><i class="material-icons left">business</i>Fornecedores</div>
<?php if ($msg): ?><div class="alerta-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="card-versatto"><div class="right-align">
    <a href="frmins.php" class="btn btn-amarelo waves-effect"><i class="material-icons left">add</i>Novo Fornecedor</a>
    <a href="/versatto/VIEW/RELATORIO/relfornecedor.php" class="btn red waves-effect" style="margin-left:6px"><i class="material-icons left">picture_as_pdf</i>PDF</a>
</div></div>
<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table responsive-table">
        <thead><tr><th>#</th><th>Razão Social</th><th>CNPJ</th><th>E-mail</th><th>Telefone</th><th>Cidade/UF</th><th class="center">Ações</th></tr></thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="7" class="center grey-text">Nenhum fornecedor cadastrado.</td></tr>
        <?php else: foreach ($lista as $f): ?>
            <tr>
                <td><?php echo $f->getId(); ?></td>
                <td><?php echo htmlspecialchars($f->getRazao()); ?></td>
                <td><?php echo htmlspecialchars($f->getCnpj()); ?></td>
                <td><?php echo htmlspecialchars($f->getEmail()); ?></td>
                <td><?php echo htmlspecialchars($f->getTelefone()); ?></td>
                <td><?php echo htmlspecialchars($f->getCidade()) . '/' . htmlspecialchars($f->getEstado()); ?></td>
                <td class="center" style="white-space:nowrap">
                    <a class="btn-floating btn-small waves-effect blue tooltipped" data-tooltip="Detalhes"
                       onclick="location.href='frmdet.php?id=<?php echo $f->getId(); ?>'"><i class="material-icons">info</i></a>
                    <a class="btn-floating btn-small waves-effect orange tooltipped" data-tooltip="Editar"
                       onclick="location.href='frmedt.php?id=<?php echo $f->getId(); ?>'"><i class="material-icons">edit</i></a>
                    <a class="btn-floating btn-small waves-effect red tooltipped" data-tooltip="Excluir"
                       onclick="confirmarRemocao(<?php echo $f->getId(); ?>,'fornecedor')"><i class="material-icons">delete</i></a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
