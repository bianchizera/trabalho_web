</div><!-- /container -->

<footer class="page-footer" style="background:#1a3a6b;margin-top:40px">
    <div class="footer-copyright">
        <div class="container center white-text" style="font-size:.85rem">
            &copy; <?php echo date('Y'); ?> Versatto Móveis Planejados &mdash; Sistema de Gestão de Estoque
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="/versatto/VIEW/js/app.js"></script>
</body>
</html>
