<?php
session_start();
session_destroy();
header("Location: /versatto/VIEW/index.php");
exit;
