/* ===== VERSATTO - JavaScript ===== */

// Inicializa componentes Materialize
document.addEventListener('DOMContentLoaded', function () {
    M.AutoInit();
    var selects   = document.querySelectorAll('select');
    M.FormSelect.init(selects);
    var sidenav   = document.querySelectorAll('.sidenav');
    M.Sidenav.init(sidenav);
    var tooltips  = document.querySelectorAll('.tooltipped');
    M.Tooltip.init(tooltips);
    var datepicker = document.querySelectorAll('.datepicker');
    M.Datepicker.init(datepicker, { format: 'yyyy-mm-dd', i18n: { months: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'], monthsShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'], weekdays: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'], weekdaysShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'], weekdaysAbbrev: ['D','S','T','Q','Q','S','S'], cancel: 'Cancelar', clear: 'Limpar', done: 'OK' } });
});

/* ===== VALIDAÇÕES ===== */
function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');
    if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
    let sum = 0, rem;
    for (let i = 1; i <= 9; i++) sum += parseInt(cpf[i - 1]) * (11 - i);
    rem = (sum * 10) % 11;
    if (rem === 10 || rem === 11) rem = 0;
    if (rem !== parseInt(cpf[9])) return false;
    sum = 0;
    for (let i = 1; i <= 10; i++) sum += parseInt(cpf[i - 1]) * (12 - i);
    rem = (sum * 10) % 11;
    if (rem === 10 || rem === 11) rem = 0;
    return rem === parseInt(cpf[10]);
}

function validarCNPJ(cnpj) {
    cnpj = cnpj.replace(/\D/g, '');
    if (cnpj.length !== 14 || /^(\d)\1+$/.test(cnpj)) return false;
    const calc = (c, l) => { let s = 0, p = l - 7; for (let i = 0; i < l; i++) { s += parseInt(c[i]) * p--; if (p < 2) p = 9; } return (s % 11 < 2 ? 0 : 11 - (s % 11)); };
    return calc(cnpj, 12) === parseInt(cnpj[12]) && calc(cnpj, 13) === parseInt(cnpj[13]);
}

function validarEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validarTelefone(tel) {
    return /^\(?\d{2}\)?[\s-]?\d{4,5}-?\d{4}$/.test(tel.replace(/\s/g, ''));
}

function mostrarErro(campo, msg) {
    campo.classList.add('invalid');
    let helper = campo.parentElement.querySelector('.helper-text');
    if (!helper) { helper = document.createElement('span'); helper.className = 'helper-text'; campo.parentElement.appendChild(helper); }
    helper.setAttribute('data-error', msg);
}
function limparErro(campo) {
    campo.classList.remove('invalid');
    campo.classList.add('valid');
}

/* ===== VALIDAÇÃO FORMULÁRIO CLIENTE ===== */
function validarFormCliente() {
    let ok = true;
    const nome = document.getElementById('nome');
    const cpf  = document.getElementById('cpf');
    const email = document.getElementById('email');
    const tel   = document.getElementById('telefone');
    const cid   = document.getElementById('cidade');
    const end   = document.getElementById('endereco');

    if (!nome || nome.value.trim().length < 3) { mostrarErro(nome, 'Nome deve ter ao menos 3 caracteres'); ok = false; } else limparErro(nome);
    if (!cpf || !validarCPF(cpf.value)) { mostrarErro(cpf, 'CPF inválido (use 000.000.000-00)'); ok = false; } else limparErro(cpf);
    if (!email || !validarEmail(email.value)) { mostrarErro(email, 'E-mail inválido'); ok = false; } else limparErro(email);
    if (!tel || !validarTelefone(tel.value)) { mostrarErro(tel, 'Telefone inválido ex: (18)99999-1111'); ok = false; } else limparErro(tel);
    if (!cid || cid.value.trim() === '') { mostrarErro(cid, 'Informe a cidade'); ok = false; } else limparErro(cid);
    if (!end || end.value.trim() === '') { mostrarErro(end, 'Informe o endereço'); ok = false; } else limparErro(end);
    return ok;
}

/* ===== VALIDAÇÃO FORMULÁRIO FORNECEDOR ===== */
function validarFormFornecedor() {
    let ok = true;
    const razao = document.getElementById('razao');
    const cnpj  = document.getElementById('cnpj');
    const email = document.getElementById('email');
    const tel   = document.getElementById('telefone');

    if (!razao || razao.value.trim().length < 3) { mostrarErro(razao, 'Razão social obrigatória'); ok = false; } else limparErro(razao);
    if (!cnpj || !validarCNPJ(cnpj.value)) { mostrarErro(cnpj, 'CNPJ inválido'); ok = false; } else limparErro(cnpj);
    if (!email || !validarEmail(email.value)) { mostrarErro(email, 'E-mail inválido'); ok = false; } else limparErro(email);
    if (!tel || !validarTelefone(tel.value)) { mostrarErro(tel, 'Telefone inválido'); ok = false; } else limparErro(tel);
    return ok;
}

/* ===== VALIDAÇÃO FORMULÁRIO PRODUTO ===== */
function validarFormProduto() {
    let ok = true;
    const desc = document.getElementById('descricao');
    const tipo = document.getElementById('tipoproduto');
    const est  = document.getElementById('estoque');
    const pc   = document.getElementById('preco_compra');

    if (!desc || desc.value.trim().length < 3) { mostrarErro(desc, 'Descrição obrigatória'); ok = false; } else limparErro(desc);
    if (!tipo || tipo.value === '') { M.toast({html:'Selecione o tipo de produto',classes:'red'}); ok = false; }
    if (!est || isNaN(est.value) || parseFloat(est.value) < 0) { mostrarErro(est, 'Estoque inválido'); ok = false; } else limparErro(est);
    if (!pc || isNaN(pc.value) || parseFloat(pc.value) <= 0) { mostrarErro(pc, 'Preço de compra inválido'); ok = false; } else limparErro(pc);
    return ok;
}

/* ===== CÁLCULO AUTOMÁTICO PREÇO DE VENDA ===== */
function calcularPrecoVenda() {
    const pc = parseFloat(document.getElementById('preco_compra')?.value) || 0;
    const pv = document.getElementById('preco_venda');
    if (pv) { pv.value = (pc * 1.20).toFixed(2); M.updateTextFields(); }
}

/* ===== MÁSCARA CPF ===== */
function mascaraCPF(v) {
    v = v.replace(/\D/g,'');
    v = v.replace(/(\d{3})(\d)/,'$1.$2');
    v = v.replace(/(\d{3})(\d)/,'$1.$2');
    v = v.replace(/(\d{3})(\d{1,2})$/,'$1-$2');
    return v;
}
function mascaraCNPJ(v) {
    v = v.replace(/\D/g,'');
    v = v.replace(/^(\d{2})(\d)/,'$1.$2');
    v = v.replace(/^(\d{2})\.(\d{3})(\d)/,'$1.$2.$3');
    v = v.replace(/\.(\d{3})(\d)/,'.$1/$2');
    v = v.replace(/(\d{4})(\d)/,'$1-$2');
    return v;
}
function mascaraTelefone(v) {
    v = v.replace(/\D/g,'');
    v = v.replace(/^(\d{2})(\d)/,'($1)$2');
    v = v.replace(/(\d{5})(\d{4})$/,'$1-$2');
    return v;
}

/* ===== ITENS DINÂMICOS COMPRA/VENDA ===== */
let itens = [];

function adicionarItem() {
    const selProd = document.getElementById('sel_produto');
    const qtdEl   = document.getElementById('item_qtd');
    const precoEl = document.getElementById('item_preco');

    const prodId    = selProd.value;
    const prodDesc  = selProd.options[selProd.selectedIndex]?.text || '';
    const qtd       = parseFloat(qtdEl.value);
    const preco     = parseFloat(precoEl.value);

    if (!prodId || prodId === '') { M.toast({html:'Selecione um produto',classes:'red'}); return; }
    if (isNaN(qtd) || qtd <= 0)  { M.toast({html:'Quantidade inválida',classes:'red'}); return; }
    if (isNaN(preco) || preco <= 0) { M.toast({html:'Preço inválido',classes:'red'}); return; }

    // Evita duplicado
    const idx = itens.findIndex(i => i.prodId == prodId);
    if (idx >= 0) { itens[idx].qtd += qtd; itens[idx].subtotal = itens[idx].qtd * itens[idx].preco; }
    else { itens.push({ prodId, prodDesc, qtd, preco, subtotal: qtd * preco }); }

    renderItens();
    qtdEl.value = ''; precoEl.value = '';
    selProd.value = '';
    M.FormSelect.init(selProd);
    M.updateTextFields();
}

function removerItem(idx) {
    itens.splice(idx, 1);
    renderItens();
}

function renderItens() {
    const tbody = document.getElementById('itens-body');
    const totalEl = document.getElementById('total-valor');
    if (!tbody) return;
    tbody.innerHTML = '';
    let total = 0;
    itens.forEach((it, i) => {
        total += it.subtotal;
        tbody.innerHTML += `<tr>
            <td>${it.prodDesc}</td>
            <td>${it.qtd}</td>
            <td>R$ ${it.preco.toFixed(2)}</td>
            <td>R$ ${it.subtotal.toFixed(2)}</td>
            <td><a class="btn-floating btn-small red" onclick="removerItem(${i})"><i class="material-icons">delete</i></a></td>
        </tr>`;
    });
    if (totalEl) totalEl.textContent = 'R$ ' + total.toFixed(2);
    document.getElementById('campo_total').value = total.toFixed(2);
    // Serializa itens em campos hidden
    document.getElementById('campo_itens').value = JSON.stringify(itens);
}

function confirmarRemocao(id, entidade) {
    if (confirm('Confirma a exclusão de ' + entidade + ' #' + id + '?')) {
        location.href = '?acao=remover&id=' + id;
    }
}
