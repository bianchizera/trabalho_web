<?php
session_start();
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/usuario.php";

$loginInput = trim($_POST['usuario'] ?? '');
$senhaInput = $_POST['senha'] ?? '';

if ($loginInput === '' || $senhaInput === '') {
    $_SESSION['erro_login'] = 'Preencha usuário e senha.';
    header("Location: /versatto/VIEW/index.php");
    exit;
}

$dal     = new DAL\Usuario();
$usuario = $dal->selectByUsuario($loginInput);

if ($usuario && $usuario->getSenha() === md5($senhaInput)) {
    $_SESSION['login']  = $usuario->getUsuario();
    $_SESSION['nome']   = $usuario->getNome();
    $_SESSION['nivel']  = $usuario->getNivel();
    $_SESSION['uid']    = $usuario->getId();
    header("Location: /versatto/VIEW/home.php");
} else {
    $_SESSION['erro_login'] = 'Usuário ou senha inválidos.';
    header("Location: /versatto/VIEW/index.php");
}
exit;
