<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';

$produtos = (new DAL\Produto())->select();
$tipos = []; foreach ((new DAL\Tipoproduto())->select() as $t) $tipos[$t->getId()] = $t->getDescricao();
$totalEstoque = array_sum(array_map(fn($p) => $p->getEstoque(), $produtos));
?>
<div class="page-title"><i class="material-icons left">warehouse</i>Relatório de Estoque</div>

<div class="card-versatto">
    <div class="right-align">
        <a href="pdfestoque.php" target="_blank" class="btn red waves-effect">
            <i class="material-icons left">picture_as_pdf</i>Exportar PDF
        </a>
    </div>
</div>

<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table responsive-table">
        <thead>
            <tr><th>#</th><th>Produto</th><th>Tipo</th><th class="right-align">Estoque</th><th>Unid.</th><th class="right-align">Preço Compra</th><th class="right-align">Preço Venda</th><th class="right-align">Valor Total Estoque</th></tr>
        </thead>
        <tbody>
        <?php foreach ($produtos as $p): $vt = $p->getEstoque() * $p->getPrecoVenda(); ?>
            <tr>
                <td><?php echo $p->getId(); ?></td>
                <td><?php echo htmlspecialchars($p->getDescricao()); ?></td>
                <td><?php echo htmlspecialchars($tipos[$p->getTipoproduto()] ?? '-'); ?></td>
                <td class="right-align <?php echo $p->getEstoque() <= 2 ? 'estoque-baixo' : ''; ?>">
                    <?php echo number_format($p->getEstoque(),2,',','.'); ?>
                </td>
                <td><?php echo $p->getUnidade(); ?></td>
                <td class="right-align">R$ <?php echo number_format($p->getPrecoCompra(),2,',','.'); ?></td>
                <td class="right-align">R$ <?php echo number_format($p->getPrecoVenda(),2,',','.'); ?></td>
                <td class="right-align">R$ <?php echo number_format($vt,2,',','.'); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr style="background:#1a3a6b;color:#fff;font-weight:bold">
                <td colspan="3" class="right-align">TOTAL</td>
                <td class="right-align"><?php echo number_format($totalEstoque,2,',','.'); ?></td>
                <td colspan="4"></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
