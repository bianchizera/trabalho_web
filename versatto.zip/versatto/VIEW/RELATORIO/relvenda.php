<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/venda.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$di  = $_GET['di']      ?? date('Y-m-01');
$df  = $_GET['df']      ?? date('Y-m-d');
$cid = isset($_GET['cliente']) && $_GET['cliente'] !== '' ? (int)$_GET['cliente'] : null;

$lista    = (new DAL\Venda())->selectPorPeriodo($di, $df, $cid);
$clientes = (new DAL\Cliente())->select();
$total    = array_sum(array_column($lista, 'total'));
?>
<div class="page-title"><i class="material-icons left">bar_chart</i>Relatório de Vendas</div>

<div class="card-versatto">
    <form method="GET" class="row" style="margin-bottom:0">
        <div class="input-field col s12 m3">
            <input id="di" name="di" type="date" value="<?php echo $di; ?>">
            <label for="di" class="active">Data Inicial</label>
        </div>
        <div class="input-field col s12 m3">
            <input id="df" name="df" type="date" value="<?php echo $df; ?>">
            <label for="df" class="active">Data Final</label>
        </div>
        <div class="input-field col s12 m4">
            <select name="cliente" id="cliente">
                <option value="">Todos os clientes</option>
                <?php foreach ($clientes as $c): ?>
                <option value="<?php echo $c->getId(); ?>" <?php echo $cid==$c->getId()?'selected':''; ?>>
                    <?php echo htmlspecialchars($c->getNome()); ?>
                </option>
                <?php endforeach; ?>
            </select>
            <label>Cliente</label>
        </div>
        <div class="col s12 m2" style="margin-top:22px">
            <button class="btn btn-versatto" type="submit"><i class="material-icons">search</i></button>
            <a href="pdfvenda.php?di=<?php echo $di; ?>&df=<?php echo $df; ?>&cliente=<?php echo $cid ?? ''; ?>"
               target="_blank" class="btn red waves-effect" style="margin-left:6px"><i class="material-icons">picture_as_pdf</i></a>
        </div>
    </form>
</div>

<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table">
        <thead><tr><th>#</th><th>Cliente</th><th>Data</th><th class="right-align">Total (R$)</th><th>Observação</th></tr></thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="5" class="center grey-text">Nenhuma venda no período.</td></tr>
        <?php else: foreach ($lista as $v): ?>
            <tr>
                <td><?php echo $v['id']; ?></td>
                <td><?php echo htmlspecialchars($v['cli_nome']); ?></td>
                <td><?php echo date('d/m/Y', strtotime($v['data_venda'])); ?></td>
                <td class="right-align">R$ <?php echo number_format($v['total'],2,',','.'); ?></td>
                <td><?php echo htmlspecialchars($v['observacao'] ?? ''); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
        <tfoot>
            <tr style="background:#1a3a6b;color:#fff;font-weight:bold">
                <td colspan="3" class="right-align">TOTAL DO PERÍODO</td>
                <td class="right-align">R$ <?php echo number_format($total,2,',','.'); ?></td>
                <td></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
