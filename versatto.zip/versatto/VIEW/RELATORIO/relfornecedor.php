<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once '_pdf_base.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';

$lista = (new DAL\Fornecedor())->select();
$pdf = new PdfVersatto('L');
$pdf->AddPage();
$pdf->TituloRelatorio('LISTAGEM DE FORNECEDORES — '.date('d/m/Y'));
$pdf->CabecalhoTabela(['#','Razão Social','CNPJ','E-mail','Telefone','Cidade/UF','Contato'],[10,55,38,55,30,30,17]);
$pdf->SetFont('Arial','',9); $fill=false;
foreach ($lista as $f) {
    $pdf->SetFillColor($fill?255:240,$fill?255:242,$fill?255:246);
    $pdf->Cell(10,6,$f->getId(),       1,0,'C',$fill);
    $pdf->Cell(55,6,$f->getRazao(),    1,0,'L',$fill);
    $pdf->Cell(38,6,$f->getCnpj(),     1,0,'C',$fill);
    $pdf->Cell(55,6,$f->getEmail(),    1,0,'L',$fill);
    $pdf->Cell(30,6,$f->getTelefone(), 1,0,'C',$fill);
    $pdf->Cell(30,6,$f->getCidade().'/'.$f->getEstado(),1,0,'L',$fill);
    $pdf->Cell(17,6,$f->getContato(),  1,1,'L',$fill);
    $fill=!$fill;
}
$pdf->Output('I','fornecedores_'.date('Ymd').'.pdf');
