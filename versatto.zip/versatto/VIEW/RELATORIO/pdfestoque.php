<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once '_pdf_base.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/produto.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';

$produtos = (new DAL\Produto())->select();
$tipos = []; foreach ((new DAL\Tipoproduto())->select() as $t) $tipos[$t->getId()] = $t->getDescricao();

$pdf = new PdfVersatto('L');
$pdf->AddPage();
$pdf->TituloRelatorio('RELATÓRIO DE ESTOQUE - ' . date('d/m/Y'));

$cols   = ['#','Produto','Tipo','Estoque','Unid.','Preço Compra','Preço Venda','Valor em Estoque'];
$widths = [10, 70, 40, 20, 15, 30, 30, 40];
$pdf->CabecalhoTabela($cols, $widths);

$pdf->SetFont('Arial', '', 9);
$fill = false; $total = 0;
foreach ($produtos as $p) {
    $vt = $p->getEstoque() * $p->getPrecoVenda(); $total += $vt;
    $pdf->SetFillColor($fill ? 255 : 240, $fill ? 255 : 242, $fill ? 255 : 246);
    if ($p->getEstoque() <= 2) $pdf->SetTextColor(198, 40, 40);
    $pdf->Cell(10, 6, $p->getId(),       1,0,'C',$fill);
    $pdf->Cell(70, 6, $p->getDescricao(),1,0,'L',$fill);
    $pdf->Cell(40, 6, $tipos[$p->getTipoproduto()]??'-',1,0,'L',$fill);
    $pdf->Cell(20, 6, number_format($p->getEstoque(),2,',','.'),1,0,'R',$fill);
    $pdf->Cell(15, 6, $p->getUnidade(),  1,0,'C',$fill);
    $pdf->Cell(30, 6, 'R$ '.number_format($p->getPrecoCompra(),2,',','.'),1,0,'R',$fill);
    $pdf->Cell(30, 6, 'R$ '.number_format($p->getPrecoVenda(),2,',','.'), 1,0,'R',$fill);
    $pdf->Cell(40, 6, 'R$ '.number_format($vt,2,',','.'),                 1,1,'R',$fill);
    $pdf->SetTextColor(0,0,0);
    $fill = !$fill;
}

$pdf->SetFont('Arial','B',9);
$pdf->SetFillColor(26,58,107); $pdf->SetTextColor(255,255,255);
$pdf->Cell(185,7,'VALOR TOTAL EM ESTOQUE',1,0,'R',true);
$pdf->Cell(40, 7,'R$ '.number_format($total,2,',','.'),1,1,'R',true);

$pdf->Output('I','estoque_'.date('Ymd').'.pdf');
