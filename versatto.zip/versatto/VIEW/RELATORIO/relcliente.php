<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once '_pdf_base.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/cliente.php';

$lista = (new DAL\Cliente())->select();
$pdf = new PdfVersatto('L');
$pdf->AddPage();
$pdf->TituloRelatorio('LISTAGEM DE CLIENTES — '.date('d/m/Y'));
$pdf->CabecalhoTabela(['#','Nome','CPF','E-mail','Telefone','Cidade/UF'],[10,60,35,65,35,30]);
$pdf->SetFont('Arial','',9); $fill=false;
foreach ($lista as $c) {
    $pdf->SetFillColor($fill?255:240,$fill?255:242,$fill?255:246);
    $pdf->Cell(10,6,$c->getId(),      1,0,'C',$fill);
    $pdf->Cell(60,6,$c->getNome(),    1,0,'L',$fill);
    $pdf->Cell(35,6,$c->getCpf(),     1,0,'C',$fill);
    $pdf->Cell(65,6,$c->getEmail(),   1,0,'L',$fill);
    $pdf->Cell(35,6,$c->getTelefone(),1,0,'C',$fill);
    $pdf->Cell(30,6,$c->getCidade().'/'.$c->getEstado(),1,1,'L',$fill);
    $fill=!$fill;
}
$pdf->Output('I','clientes_'.date('Ymd').'.pdf');
