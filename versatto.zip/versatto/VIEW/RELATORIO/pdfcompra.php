<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once '_pdf_base.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/compra.php';

$di   = $_GET['di'] ?? date('Y-m-01');
$df   = $_GET['df'] ?? date('Y-m-d');
$fid  = isset($_GET['fornecedor']) && $_GET['fornecedor']!=='' ? (int)$_GET['fornecedor'] : null;
$lista = (new DAL\Compra())->selectPorPeriodo($di, $df, $fid);
$total = array_sum(array_column($lista,'total'));

$pdf = new PdfVersatto();
$pdf->AddPage();
$pdf->TituloRelatorio('RELATÓRIO DE COMPRAS — ' . date('d/m/Y', strtotime($di)) . ' a ' . date('d/m/Y', strtotime($df)));

$pdf->CabecalhoTabela(['#','Fornecedor','Data','Total (R$)','Observação'],[15,70,30,35,50]);
$pdf->SetFont('Arial','',9); $fill=false;
foreach ($lista as $c) {
    $pdf->SetFillColor($fill?255:240,$fill?255:242,$fill?255:246);
    $pdf->Cell(15,6,$c['id'],        1,0,'C',$fill);
    $pdf->Cell(70,6,$c['razao'],     1,0,'L',$fill);
    $pdf->Cell(30,6,date('d/m/Y',strtotime($c['data_compra'])),1,0,'C',$fill);
    $pdf->Cell(35,6,'R$ '.number_format($c['total'],2,',','.'),1,0,'R',$fill);
    $pdf->Cell(50,6,substr($c['observacao']??'',0,40),1,1,'L',$fill);
    $fill=!$fill;
}
$pdf->SetFont('Arial','B',9);
$pdf->SetFillColor(26,58,107);$pdf->SetTextColor(255,255,255);
$pdf->Cell(150,7,'TOTAL',1,0,'R',true);
$pdf->Cell(35,7,'R$ '.number_format($total,2,',','.'),1,1,'R',true);

$pdf->Output('I','compras_'.date('Ymd').'.pdf');
