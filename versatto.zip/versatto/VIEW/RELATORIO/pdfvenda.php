<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once '_pdf_base.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/venda.php';

$di    = $_GET['di'] ?? date('Y-m-01');
$df    = $_GET['df'] ?? date('Y-m-d');
$cid   = isset($_GET['cliente']) && $_GET['cliente']!=='' ? (int)$_GET['cliente'] : null;
$lista = (new DAL\Venda())->selectPorPeriodo($di, $df, $cid);
$total = array_sum(array_column($lista,'total'));

$pdf = new PdfVersatto();
$pdf->AddPage();
$pdf->TituloRelatorio('RELATÓRIO DE VENDAS — '.date('d/m/Y',strtotime($di)).' a '.date('d/m/Y',strtotime($df)));

$pdf->CabecalhoTabela(['#','Cliente','Data','Total (R$)','Observação'],[15,70,30,35,50]);
$pdf->SetFont('Arial','',9); $fill=false;
foreach ($lista as $v) {
    $pdf->SetFillColor($fill?255:240,$fill?255:242,$fill?255:246);
    $pdf->Cell(15,6,$v['id'],         1,0,'C',$fill);
    $pdf->Cell(70,6,$v['cli_nome'],   1,0,'L',$fill);
    $pdf->Cell(30,6,date('d/m/Y',strtotime($v['data_venda'])),1,0,'C',$fill);
    $pdf->Cell(35,6,'R$ '.number_format($v['total'],2,',','.'),1,0,'R',$fill);
    $pdf->Cell(50,6,substr($v['observacao']??'',0,40),1,1,'L',$fill);
    $fill=!$fill;
}
$pdf->SetFont('Arial','B',9);
$pdf->SetFillColor(26,58,107);$pdf->SetTextColor(255,255,255);
$pdf->Cell(150,7,'TOTAL',1,0,'R',true);
$pdf->Cell(35,7,'R$ '.number_format($total,2,',','.'),1,1,'R',true);

$pdf->Output('I','vendas_'.date('Ymd').'.pdf');
