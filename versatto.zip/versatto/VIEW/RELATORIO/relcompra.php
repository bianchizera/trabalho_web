<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/compra.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/fornecedor.php';

$di   = $_GET['di']   ?? date('Y-m-01');
$df   = $_GET['df']   ?? date('Y-m-d');
$fid  = isset($_GET['fornecedor']) && $_GET['fornecedor'] !== '' ? (int)$_GET['fornecedor'] : null;

$lista = (new DAL\Compra())->selectPorPeriodo($di, $df, $fid);
$fornecedores = (new DAL\Fornecedor())->select();
$total = array_sum(array_column($lista, 'total'));
?>
<div class="page-title"><i class="material-icons left">assessment</i>Relatório de Compras</div>

<div class="card-versatto">
    <form method="GET" class="row" style="margin-bottom:0">
        <div class="input-field col s12 m3">
            <input id="di" name="di" type="date" value="<?php echo $di; ?>">
            <label for="di" class="active">Data Inicial</label>
        </div>
        <div class="input-field col s12 m3">
            <input id="df" name="df" type="date" value="<?php echo $df; ?>">
            <label for="df" class="active">Data Final</label>
        </div>
        <div class="input-field col s12 m4">
            <select name="fornecedor" id="fornecedor">
                <option value="">Todos os fornecedores</option>
                <?php foreach ($fornecedores as $f): ?>
                <option value="<?php echo $f->getId(); ?>" <?php echo $fid==$f->getId()?'selected':''; ?>>
                    <?php echo htmlspecialchars($f->getRazao()); ?>
                </option>
                <?php endforeach; ?>
            </select>
            <label>Fornecedor</label>
        </div>
        <div class="col s12 m2" style="margin-top:22px">
            <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons">search</i></button>
            <a href="pdfcompra.php?di=<?php echo $di; ?>&df=<?php echo $df; ?>&fornecedor=<?php echo $fid ?? ''; ?>"
               target="_blank" class="btn red waves-effect" style="margin-left:6px"><i class="material-icons">picture_as_pdf</i></a>
        </div>
    </form>
</div>

<div class="card-versatto" style="padding:0;overflow-x:auto">
    <table class="versatto-table">
        <thead><tr><th>#</th><th>Fornecedor</th><th>Data</th><th class="right-align">Total (R$)</th><th>Observação</th></tr></thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="5" class="center grey-text">Nenhuma compra no período.</td></tr>
        <?php else: foreach ($lista as $c): ?>
            <tr>
                <td><?php echo $c['id']; ?></td>
                <td><?php echo htmlspecialchars($c['razao']); ?></td>
                <td><?php echo date('d/m/Y', strtotime($c['data_compra'])); ?></td>
                <td class="right-align">R$ <?php echo number_format($c['total'],2,',','.'); ?></td>
                <td><?php echo htmlspecialchars($c['observacao'] ?? ''); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
        <tfoot>
            <tr style="background:#1a3a6b;color:#fff;font-weight:bold">
                <td colspan="3" class="right-align">TOTAL DO PERÍODO</td>
                <td class="right-align">R$ <?php echo number_format($total,2,',','.'); ?></td>
                <td></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php include_once dirname(__DIR__) . '/footer.php'; ?>
