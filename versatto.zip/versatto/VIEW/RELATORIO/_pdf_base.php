<?php
/**
 * Base para geração de PDF com FPDF
 * Baixar fpdf.php de http://www.fpdf.org e colocar em /versatto/lib/fpdf/fpdf.php
 */
if (!file_exists($_SERVER['DOCUMENT_ROOT'] . '/versatto/lib/fpdf/fpdf.php')) {
    die('<h3>Instale o FPDF: copie <b>fpdf.php</b> para <code>/versatto/lib/fpdf/fpdf.php</code><br>
         Baixe em: <a href="http://fpdf.org">fpdf.org</a></h3>');
}
require_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/lib/fpdf/fpdf.php';

class PdfVersatto extends FPDF {
    function Header() {
        // Logo
        $logo = $_SERVER['DOCUMENT_ROOT'] . '/versatto/VIEW/images/logo.jpeg';
        if (file_exists($logo)) $this->Image($logo, 10, 6, 30);
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(26, 58, 107);
        $this->SetXY(45, 10);
        $this->Cell(0, 8, 'VERSATTO - Móveis Planejados', 0, 1, 'L');
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(96, 125, 139);
        $this->SetX(45);
        $this->Cell(0, 5, 'Sistema de Controle de Estoque', 0, 1, 'L');
        $this->Ln(4);
        $this->SetDrawColor(245, 200, 66);
        $this->SetLineWidth(1.2);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(4);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(150);
        $this->Cell(0, 10, 'Gerado em: ' . date('d/m/Y H:i') . '   |   Página ' . $this->PageNo(), 0, 0, 'C');
    }

    function TituloRelatorio(string $titulo) {
        $this->SetFont('Arial', 'B', 13);
        $this->SetFillColor(26, 58, 107);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(0, 8, $titulo, 0, 1, 'L', true);
        $this->SetTextColor(0, 0, 0);
        $this->Ln(2);
    }

    function CabecalhoTabela(array $cols, array $widths) {
        $this->SetFont('Arial', 'B', 9);
        $this->SetFillColor(26, 58, 107);
        $this->SetTextColor(255, 255, 255);
        foreach ($cols as $i => $col)
            $this->Cell($widths[$i], 7, $col, 1, 0, 'C', true);
        $this->Ln();
        $this->SetTextColor(0, 0, 0);
    }
}
