<?php include_once 'menu.php'; ?>

<div class="home-hero">
    <img src="/versatto/VIEW/images/logo.jpeg" alt="Versatto">
    <h3 style="margin-top:20px;font-weight:bold">Versatto Móveis Planejados</h3>
    <p style="font-size:1.1rem;opacity:.9">Sistema de Controle de Estoque &mdash; versão 1.0</p>
</div>

<div class="row home-cards" style="margin-top:28px">
    <div class="col s12 m4">
        <div class="card-versatto center">
            <i class="material-icons home-cards" style="font-size:3rem;color:#f5c842">people</i>
            <h6 style="color:#1a3a6b;font-weight:bold">Clientes</h6>
            <p>Cadastro completo de clientes com CPF, e-mail e telefone.</p>
            <a href="/versatto/VIEW/CLIENTE/lstcliente.php" class="btn btn-versatto">Acessar</a>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card-versatto center">
            <i class="material-icons" style="font-size:3rem;color:#f5c842">inventory_2</i>
            <h6 style="color:#1a3a6b;font-weight:bold">Produtos</h6>
            <p>Gerencie produtos, estoque, preços de compra e venda.</p>
            <a href="/versatto/VIEW/PRODUTO/lstproduto.php" class="btn btn-versatto">Acessar</a>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card-versatto center">
            <i class="material-icons" style="font-size:3rem;color:#f5c842">point_of_sale</i>
            <h6 style="color:#1a3a6b;font-weight:bold">Vendas</h6>
            <p>Registre vendas, atualize estoque automaticamente.</p>
            <a href="/versatto/VIEW/VENDA/lstvenda.php" class="btn btn-versatto">Acessar</a>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card-versatto center">
            <i class="material-icons" style="font-size:3rem;color:#f5c842">add_shopping_cart</i>
            <h6 style="color:#1a3a6b;font-weight:bold">Compras</h6>
            <p>Registre compras de fornecedores e atualize estoque e preços.</p>
            <a href="/versatto/VIEW/COMPRA/lstcompra.php" class="btn btn-versatto">Acessar</a>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card-versatto center">
            <i class="material-icons" style="font-size:3rem;color:#f5c842">assessment</i>
            <h6 style="color:#1a3a6b;font-weight:bold">Relatórios</h6>
            <p>Relatórios de vendas, compras e estoque com saída em PDF.</p>
            <a href="/versatto/VIEW/RELATORIO/relestoque.php" class="btn btn-versatto">Acessar</a>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card-versatto center">
            <i class="material-icons" style="font-size:3rem;color:#f5c842">business</i>
            <h6 style="color:#1a3a6b;font-weight:bold">Fornecedores</h6>
            <p>Cadastro de fornecedores com CNPJ, contato e localização.</p>
            <a href="/versatto/VIEW/FORNECEDOR/lstfornecedor.php" class="btn btn-versatto">Acessar</a>
        </div>
    </div>
</div>

<?php include_once 'footer.php'; ?>
