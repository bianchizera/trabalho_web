<?php
include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
$id = (int)($_GET['id'] ?? 0);
$t  = (new DAL\Tipoproduto())->selectById($id);
if (!$t) { header("Location: lsttipoproduto.php"); exit; }
?>
<div class="page-title"><i class="material-icons left">edit</i>Editar Tipo de Produto</div>
<div class="card-versatto">
    <form method="POST" action="opedt.php">
        <input type="hidden" name="id" value="<?php echo $t->getId(); ?>">
        <div class="row">
            <div class="input-field col s12 m8">
                <input id="descricao" name="descricao" type="text" maxlength="50" value="<?php echo htmlspecialchars($t->getDescricao()); ?>" required>
                <label for="descricao" class="active">Descrição *</label>
            </div>
        </div>
        <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
        <a href="lsttipoproduto.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
    </form>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
