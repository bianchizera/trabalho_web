<?php include_once dirname(__DIR__) . '/menu.php'; ?>
<div class="page-title"><i class="material-icons left">add</i>Novo Tipo de Produto</div>
<div class="card-versatto">
    <form method="POST" action="opins.php" onsubmit="if(!document.getElementById('descricao').value.trim()){alert('Informe a descrição');return false;}">
        <div class="row">
            <div class="input-field col s12 m8">
                <input id="descricao" name="descricao" type="text" maxlength="50" required>
                <label for="descricao">Descrição *</label>
            </div>
        </div>
        <button class="btn btn-versatto waves-effect" type="submit"><i class="material-icons left">save</i>Salvar</button>
        <a href="lsttipoproduto.php" class="btn grey waves-effect" style="margin-left:8px"><i class="material-icons left">arrow_back</i>Voltar</a>
    </form>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
