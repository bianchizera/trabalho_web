<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
$o = new \MODEL\Tipoproduto(); $o->setId((int)$_POST['id']); $o->setDescricao(trim($_POST['descricao']));
$_SESSION['msg'] = (new DAL\Tipoproduto())->update($o) ? 'Atualizado!' : 'Erro.';
header("Location: lsttipoproduto.php"); exit;
