<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['login'])) { header("Location: /versatto/VIEW/index.php"); exit; }

if (isset($_GET['acao']) && $_GET['acao'] === 'remover' && isset($_GET['id'])) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
    (new DAL\Tipoproduto())->delete((int)$_GET['id']);
    $_SESSION['msg'] = 'Tipo excluído.';
    header("Location: lsttipoproduto.php"); exit;
}

include_once dirname(__DIR__) . '/menu.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';

$dal  = new DAL\Tipoproduto();
$lista = $dal->select();
$msg  = $_SESSION['msg'] ?? ''; unset($_SESSION['msg']);
?>
<div class="page-title"><i class="material-icons left">category</i>Tipos de Produto</div>
<?php if ($msg): ?><div class="alerta-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="card-versatto"><div class="right-align">
    <a href="frmins.php" class="btn btn-amarelo waves-effect"><i class="material-icons left">add</i>Novo Tipo</a>
</div></div>
<div class="card-versatto" style="padding:0">
    <table class="versatto-table">
        <thead><tr><th>#</th><th>Descrição</th><th class="center">Ações</th></tr></thead>
        <tbody>
        <?php if (empty($lista)): ?>
            <tr><td colspan="3" class="center grey-text">Nenhum tipo cadastrado.</td></tr>
        <?php else: foreach ($lista as $t): ?>
            <tr>
                <td><?php echo $t->getId(); ?></td>
                <td><?php echo htmlspecialchars($t->getDescricao()); ?></td>
                <td class="center">
                    <a class="btn-floating btn-small waves-effect orange" onclick="location.href='frmedt.php?id=<?php echo $t->getId(); ?>'"><i class="material-icons">edit</i></a>
                    <a class="btn-floating btn-small waves-effect red" onclick="confirmarRemocao(<?php echo $t->getId(); ?>,'tipo')"><i class="material-icons">delete</i></a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
<?php include_once dirname(__DIR__) . '/footer.php'; ?>
