<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION["login"])) { header("Location: /versatto/VIEW/index.php"); exit; }
include_once $_SERVER['DOCUMENT_ROOT'] . '/versatto/DAL/tipoproduto.php';
$o = new \MODEL\Tipoproduto(); $o->setDescricao(trim($_POST['descricao']));
$_SESSION['msg'] = (new DAL\Tipoproduto())->insert($o) ? 'Tipo cadastrado!' : 'Erro.';
header("Location: lsttipoproduto.php"); exit;
