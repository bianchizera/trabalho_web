<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/fornecedor.php";

class Fornecedor {

    private function hydrate(array $row): \MODEL\Fornecedor {
        $obj = new \MODEL\Fornecedor();
        $obj->setId((int)$row['id']);
        $obj->setRazao($row['razao']);
        $obj->setCnpj($row['cnpj']);
        $obj->setEmail($row['email']);
        $obj->setTelefone($row['telefone']);
        $obj->setCidade($row['cidade']);
        $obj->setEstado($row['estado']);
        $obj->setContato($row['contato'] ?? '');    
        return $obj;
    }

    public function select(): array {
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query("SELECT * FROM fornecedor ORDER BY razao") as $row)
            $lst[] = $this->hydrate($row);
        Conexao::desconectar();
        return $lst;
    }

    public function selectById(int $id): ?\MODEL\Fornecedor {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM fornecedor WHERE id=?");
        $q->execute([$id]);
        $row = $q->fetch();
        Conexao::desconectar();
        return $row ? $this->hydrate($row) : null;
    }

    public function insert(\MODEL\Fornecedor $o): bool {
        $sql = "INSERT INTO fornecedor (razao,cnpj,email,telefone,cidade,estado,contato) VALUES (?,?,?,?,?,?,?)";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$o->getRazao(),$o->getCnpj(),$o->getEmail(),$o->getTelefone(),$o->getCidade(),$o->getEstado(),$o->getContato()]);
        Conexao::desconectar();
        return $res;
    }

    public function update(\MODEL\Fornecedor $o): bool {
        $sql = "UPDATE fornecedor SET razao=?,cnpj=?,email=?,telefone=?,cidade=?,estado=?,contato=? WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$o->getRazao(),$o->getCnpj(),$o->getEmail(),$o->getTelefone(),$o->getCidade(),$o->getEstado(),$o->getContato(),$o->getId()]);
        Conexao::desconectar();
        return $res;
    }

    public function delete(int $id): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("DELETE FROM fornecedor WHERE id=?");
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }
}
