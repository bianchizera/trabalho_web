<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/venda.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/itemvenda.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/produto.php";

class Venda {

    public function select(): array {
        $sql = "SELECT v.*, c.nome AS cli_nome FROM venda v JOIN cliente c ON c.id=v.cliente ORDER BY v.data_venda DESC";
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query($sql) as $row) {
            $obj = new \MODEL\Venda();
            $obj->setId((int)$row['id']);
            $obj->setCliente((int)$row['cliente']);
            $obj->setDataVenda($row['data_venda']);
            $obj->setTotal((float)$row['total']);
            $obj->setObservacao($row['observacao'] ?? '');
            $lst[] = $obj;
        }
        Conexao::desconectar();
        return $lst;
    }

    public function selectById(int $id): ?\MODEL\Venda {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM venda WHERE id=?");
        $q->execute([$id]);
        $row = $q->fetch();
        Conexao::desconectar();
        if (!$row) return null;
        $obj = new \MODEL\Venda();
        $obj->setId((int)$row['id']);
        $obj->setCliente((int)$row['cliente']);
        $obj->setDataVenda($row['data_venda']);
        $obj->setTotal((float)$row['total']);
        $obj->setObservacao($row['observacao'] ?? '');
        return $obj;
    }

    public function selectItens(int $vendaId): array {
        $sql = "SELECT iv.*, p.descricao AS prod_desc
                FROM itens_venda iv JOIN produto p ON p.id=iv.produto
                WHERE iv.venda=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $q->execute([$vendaId]);
        $lst = [];
        foreach ($q->fetchAll() as $row) {
            $obj = new \MODEL\Itemvenda();
            $obj->setId((int)$row['id']);
            $obj->setVenda((int)$row['venda']);
            $obj->setProduto((int)$row['produto']);
            $obj->setQuantidade((float)$row['quantidade']);
            $obj->setPrecoVenda((float)$row['preco_venda']);
            $obj->setSubtotal((float)$row['subtotal']);
            $lst[] = $obj;
        }
        Conexao::desconectar();
        return $lst;
    }

    public function inserirComItens(\MODEL\Venda $venda, array $itens): string {
        $con = Conexao::conectar();
        $con->beginTransaction();
        try {
            $dalProd = new Produto();
            foreach ($itens as $item) {
                $prod = $dalProd->selectById($item->getProduto());
                if (!$prod || $prod->getEstoque() < $item->getQuantidade()) {
                    $con->rollBack();
                    Conexao::desconectar();
                    return "Estoque insuficiente para: " . ($prod ? $prod->getDescricao() : "produto #" . $item->getProduto());
                }
            }

            $q = $con->prepare("INSERT INTO venda (cliente,data_venda,total,observacao) VALUES (?,?,?,?)");
            $q->execute([$venda->getCliente(), $venda->getDataVenda(), $venda->getTotal(), $venda->getObservacao()]);
            $vendaId = (int)$con->lastInsertId();

            $qi = $con->prepare("INSERT INTO itens_venda (venda,produto,quantidade,preco_venda,subtotal) VALUES (?,?,?,?,?)");
            foreach ($itens as $item) {
                $qi->execute([$vendaId, $item->getProduto(), $item->getQuantidade(), $item->getPrecoVenda(), $item->getSubtotal()]);
                $dalProd->baixarEstoque($item->getProduto(), $item->getQuantidade());
            }
            $con->commit();
            Conexao::desconectar();
            return "ok";
        } catch (\Exception $e) {
            $con->rollBack();
            Conexao::desconectar();
            return "Erro: " . $e->getMessage();
        }
    }

    public function selectPorPeriodo(string $di, string $df, ?int $clienteId = null): array {
        $sql = "SELECT v.*, c.nome AS cli_nome FROM venda v JOIN cliente c ON c.id=v.cliente
                WHERE v.data_venda BETWEEN ? AND ?";
        $params = [$di, $df];
        if ($clienteId) { $sql .= " AND v.cliente=?"; $params[] = $clienteId; }
        $sql .= " ORDER BY v.data_venda DESC";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $q->execute($params);
        $lst = $q->fetchAll();
        Conexao::desconectar();
        return $lst;
    }

    public function delete(int $id): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("DELETE FROM venda WHERE id=?");
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }
}