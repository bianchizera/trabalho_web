<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/compra.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/itemcompra.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/produto.php";

class Compra {

    public function select(): array {
        $sql = "SELECT c.*, f.razao FROM compra c JOIN fornecedor f ON f.id=c.fornecedor ORDER BY c.data_compra DESC";
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query($sql) as $row) {
            $obj = new \MODEL\Compra();
            $obj->setId((int)$row['id']);
            $obj->setFornecedor((int)$row['fornecedor']);
            $obj->setDataCompra($row['data_compra']);
            $obj->setTotal((float)$row['total']);
            $obj->setObservacao($row['observacao'] ?? '');
            $lst[] = $obj;
        }
        Conexao::desconectar();
        return $lst;
    }

    public function selectById(int $id): ?\MODEL\Compra {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM compra WHERE id=?");
        $q->execute([$id]);
        $row = $q->fetch();
        Conexao::desconectar();
        if (!$row) return null;
        $obj = new \MODEL\Compra();
        $obj->setId((int)$row['id']);
        $obj->setFornecedor((int)$row['fornecedor']);
        $obj->setDataCompra($row['data_compra']);
        $obj->setTotal((float)$row['total']);
        $obj->setObservacao($row['observacao'] ?? '');
        return $obj;
    }

    public function selectItens(int $compraId): array {
        $sql = "SELECT ic.*, p.descricao AS prod_desc
                FROM itens_compra ic JOIN produto p ON p.id=ic.produto
                WHERE ic.compra=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $q->execute([$compraId]);
        $lst = [];
        foreach ($q->fetchAll() as $row) {
            $obj = new \MODEL\Itemcompra();
            $obj->setId((int)$row['id']);
            $obj->setCompra((int)$row['compra']);
            $obj->setProduto((int)$row['produto']);
            $obj->setQuantidade((float)$row['quantidade']);
            $obj->setPrecoCompra((float)$row['preco_compra']);
            $obj->setSubtotal((float)$row['subtotal']);
            $lst[] = $obj;
        }
        Conexao::desconectar();
        return $lst;
    }

    public function inserirComItens(\MODEL\Compra $compra, array $itens): bool {
        $con = Conexao::conectar();
        $con->beginTransaction();
        try {
            $q = $con->prepare("INSERT INTO compra (fornecedor,data_compra,total,observacao) VALUES (?,?,?,?)");
            $q->execute([$compra->getFornecedor(), $compra->getDataCompra(), $compra->getTotal(), $compra->getObservacao()]);
            $compraId = (int)$con->lastInsertId();

            $qi = $con->prepare("INSERT INTO itens_compra (compra,produto,quantidade,preco_compra,subtotal) VALUES (?,?,?,?,?)");
            $dalProd = new Produto();
            foreach ($itens as $item) {
                $qi->execute([$compraId, $item->getProduto(), $item->getQuantidade(), $item->getPrecoCompra(), $item->getSubtotal()]);
                $dalProd->atualizarEstoqueCompra($item->getProduto(), $item->getQuantidade(), $item->getPrecoCompra());
            }
            $con->commit();
            Conexao::desconectar();
            return true;
        } catch (\Exception $e) {
            $con->rollBack();
            Conexao::desconectar();
            return false;
        }
    }

    public function selectPorPeriodo(string $di, string $df, ?int $fornecedorId = null): array {
        $sql = "SELECT c.*, f.razao FROM compra c JOIN fornecedor f ON f.id=c.fornecedor
                WHERE c.data_compra BETWEEN ? AND ?";
        $params = [$di, $df];
        if ($fornecedorId) { $sql .= " AND c.fornecedor=?"; $params[] = $fornecedorId; }
        $sql .= " ORDER BY c.data_compra DESC";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $q->execute($params);
        $lst = $q->fetchAll();
        Conexao::desconectar();
        return $lst;
    }

    public function delete(int $id): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("DELETE FROM compra WHERE id=?");
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }
}