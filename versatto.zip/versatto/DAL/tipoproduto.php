<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/tipoproduto.php";

class Tipoproduto {

    private function hydrate(array $row): \MODEL\Tipoproduto {
    $obj = new \MODEL\Tipoproduto();
    $obj->setId((int)$row['id']);
    $obj->setDescricao($row['descricao']);
    return $obj;
}

    public function select(): array {
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query("SELECT * FROM tipo_produto ORDER BY descricao") as $row)
            $lst[] = $this->hydrate($row);
        Conexao::desconectar();
        return $lst;
    }

    public function selectById(int $id): ?\MODEL\Tipoproduto {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM tipo_produto WHERE id=?");
        $q->execute([$id]);
        $row = $q->fetch();
        Conexao::desconectar();
        return $row ? $this->hydrate($row) : null;
    }

    public function insert(\MODEL\Tipoproduto $o): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("INSERT INTO tipo_produto (descricao) VALUES (?)");
        $res = $q->execute([$o->getDescricao()]);
        Conexao::desconectar();
        return $res;
    }

    public function update(\MODEL\Tipoproduto $o): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("UPDATE tipo_produto SET descricao=? WHERE id=?");
        $res = $q->execute([$o->getDescricao(), $o->getId()]);
        Conexao::desconectar();
        return $res;
    }

    public function delete(int $id): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("DELETE FROM tipo_produto WHERE id=?");
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }
}