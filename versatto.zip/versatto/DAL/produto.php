<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/produto.php";

class Produto {

    private function hydrate(array $row): \MODEL\Produto {
        $obj = new \MODEL\Produto();
        $obj->setId((int)$row['id']);
        $obj->setDescricao($row['descricao']);
        $obj->setTipoproduto((int)$row['tipo_produto']);
        $obj->setFornecedor((int)$row['fornecedor']);
        $obj->setEstoque((float)$row['estoque']);
        $obj->setPrecoCompra((float)$row['preco_compra']);
        $obj->setPrecoVenda((float)$row['preco_venda']);
        $obj->setUnidade($row['unidade']);
        return $obj;
    }

    public function select(): array {
        $sql = "SELECT p.*, t.descricao AS tipo_desc
                FROM produto p
                JOIN tipo_produto t ON t.id = p.tipo_produto
                ORDER BY p.descricao";
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query($sql) as $row)
            $lst[] = $this->hydrate($row);
        Conexao::desconectar();
        return $lst;
    }

    public function selectById(int $id): ?\MODEL\Produto {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM produto WHERE id=?");
        $q->execute([$id]);
        $row = $q->fetch();
        Conexao::desconectar();
        return $row ? $this->hydrate($row) : null;
    }

    public function selectByDescricao(string $termo): array {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM produto WHERE descricao LIKE ? ORDER BY descricao");
        $q->execute(["%$termo%"]);
        $lst = [];
        foreach ($q->fetchAll() as $row)
            $lst[] = $this->hydrate($row);
        Conexao::desconectar();
        return $lst;
    }

    public function insert(\MODEL\Produto $o): bool {
        $sql = "INSERT INTO produto (descricao, tipo_produto, fornecedor, estoque, preco_compra, preco_venda, unidade)
                VALUES (?,?,?,?,?,?,?)";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([
            $o->getDescricao(), $o->getTipoproduto(), $o->getFornecedor(), $o->getEstoque(),
            $o->getPrecoCompra(), $o->getPrecoVenda(), $o->getUnidade()
        ]);
        Conexao::desconectar();
        return $res;
    }

    public function update(\MODEL\Produto $o): bool {
        $sql = "UPDATE produto SET descricao=?, tipo_produto=?, fornecedor=?, estoque=?,
                preco_compra=?, preco_venda=?, unidade=? WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([
            $o->getDescricao(), $o->getTipoproduto(), $o->getFornecedor(), $o->getEstoque(),
            $o->getPrecoCompra(), $o->getPrecoVenda(), $o->getUnidade(), $o->getId()
        ]);
        Conexao::desconectar();
        return $res;
    }

    public function delete(int $id): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("DELETE FROM produto WHERE id=?");
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }

    public function atualizarEstoqueCompra(int $id, float $qtd, float $precoCompra): bool {
        $precoVenda = round($precoCompra * 1.20, 2);
        $sql = "UPDATE produto SET estoque = estoque + ?, preco_compra=?, preco_venda=? WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$qtd, $precoCompra, $precoVenda, $id]);
        Conexao::desconectar();
        return $res;
    }

    public function baixarEstoque(int $id, float $qtd): bool {
        $sql = "UPDATE produto SET estoque = estoque - ? WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$qtd, $id]);
        Conexao::desconectar();
        return $res;
    }
}