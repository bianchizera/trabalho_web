-- ============================================================
-- VERSATTO - Móveis Planejados
-- ============================================================
CREATE DATABASE IF NOT EXISTS `versatto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `versatto`;

DROP TABLE IF EXISTS `itens_venda`;
DROP TABLE IF EXISTS `itens_compra`;
DROP TABLE IF EXISTS `venda`;
DROP TABLE IF EXISTS `compra`;
DROP TABLE IF EXISTS `produto`;
DROP TABLE IF EXISTS `cliente`;
DROP TABLE IF EXISTS `fornecedor`;
DROP TABLE IF EXISTS `tipo_produto`;
DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nome` VARCHAR(80) NOT NULL,
  `usuario` VARCHAR(40) NOT NULL UNIQUE,
  `senha` VARCHAR(32) NOT NULL COMMENT 'MD5',
  `nivel` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `usuario` (`nome`,`usuario`,`senha`,`nivel`) VALUES
('Administrador','admin',MD5('admin123'),2),
('Vendedor João','joao',MD5('joao123'),1);

CREATE TABLE `tipo_produto` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `descricao` VARCHAR(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tipo_produto` (`descricao`) VALUES
('Armário'),('Cozinha Planejada'),('Closet'),('Guarda-Roupa'),
('Painel de TV'),('Escrivaninha'),('Estante'),('Rack');

CREATE TABLE `fornecedor` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `razao` VARCHAR(100) NOT NULL,
  `cnpj` VARCHAR(18) NOT NULL,
  `telefone` VARCHAR(15) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `cidade` VARCHAR(60) NOT NULL,
  `estado` CHAR(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `fornecedor` (`razao`,`cnpj`,`telefone`,`email`,`cidade`,`estado`) VALUES
('MadeiraMaster Ltda','12.345.678/0001-90','(11) 3333-1111','contato@madeiramaster.com.br','São Paulo','SP'),
('Ferragens & Cia','98.765.432/0001-10','(11) 4444-2222','vendas@ferragensecia.com.br','Guarulhos','SP'),
('Puxadores Premium S/A','11.222.333/0001-44','(19) 5555-3333','comercial@puxadores.com.br','Campinas','SP');

CREATE TABLE `produto` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `descricao` VARCHAR(100) NOT NULL,
  `tipo_produto` INT NOT NULL,
  `fornecedor` INT NOT NULL,
  `estoque` FLOAT NOT NULL DEFAULT 0,
  `preco_compra` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `preco_venda` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `unidade` VARCHAR(10) NOT NULL DEFAULT 'UN',
  CONSTRAINT `fk_prod_tipo` FOREIGN KEY (`tipo_produto`) REFERENCES `tipo_produto`(`id`),
  CONSTRAINT `fk_prod_forn` FOREIGN KEY (`fornecedor`) REFERENCES `fornecedor`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `produto` (`descricao`,`tipo_produto`,`fornecedor`,`estoque`,`preco_compra`,`preco_venda`,`unidade`) VALUES
('Armário de Cozinha 2 Portas MDF',2,1,10,850.00,1020.00,'UN'),
('Guarda-Roupa 6 Portas Espelhado',4,1,5,1200.00,1440.00,'UN'),
('Closet Completo com Gavetas',3,1,3,2500.00,3000.00,'UN'),
('Painel de TV 65" com Nichos',5,2,8,650.00,780.00,'UN'),
('Estante Biblioteca 5 Prateleiras',7,1,12,480.00,576.00,'UN'),
('Rack Suspenso para Sala',8,2,7,390.00,468.00,'UN');

CREATE TABLE `cliente` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nome` VARCHAR(100) NOT NULL,
  `cpf` VARCHAR(14) NOT NULL,
  `telefone` VARCHAR(15) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `cidade` VARCHAR(60) NOT NULL,
  `estado` CHAR(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `cliente` (`nome`,`cpf`,`telefone`,`email`,`cidade`,`estado`) VALUES
('Maria Silva Santos','123.456.789-00','(11) 91111-1111','maria.silva@email.com','São Paulo','SP'),
('Carlos Eduardo Rocha','987.654.321-00','(11) 92222-2222','carlos.rocha@email.com','Santo André','SP'),
('Ana Paula Ferreira','456.789.123-00','(19) 93333-3333','ana.ferreira@email.com','Campinas','SP');

CREATE TABLE `compra` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fornecedor` INT NOT NULL,
  `data_compra` DATE NOT NULL,
  `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `observacao` TEXT,
  CONSTRAINT `fk_compra_forn` FOREIGN KEY (`fornecedor`) REFERENCES `fornecedor`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `itens_compra` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `compra` INT NOT NULL,
  `produto` INT NOT NULL,
  `quantidade` FLOAT NOT NULL,
  `preco_compra` DECIMAL(10,2) NOT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  CONSTRAINT `fk_ic_compra` FOREIGN KEY (`compra`) REFERENCES `compra`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ic_produto` FOREIGN KEY (`produto`) REFERENCES `produto`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `venda` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `cliente` INT NOT NULL,
  `data_venda` DATE NOT NULL,
  `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `observacao` TEXT,
  CONSTRAINT `fk_venda_cli` FOREIGN KEY (`cliente`) REFERENCES `cliente`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `itens_venda` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `venda` INT NOT NULL,
  `produto` INT NOT NULL,
  `quantidade` FLOAT NOT NULL,
  `preco_venda` DECIMAL(10,2) NOT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  CONSTRAINT `fk_iv_venda` FOREIGN KEY (`venda`) REFERENCES `venda`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iv_produto` FOREIGN KEY (`produto`) REFERENCES `produto`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
