<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/cliente.php";

class Cliente {

    private function hydrate(array $row): \MODEL\Cliente {
        $obj = new \MODEL\Cliente();
        $obj->setId((int)$row['id']);
        $obj->setNome($row['nome']);
        $obj->setCpf($row['cpf']);
        $obj->setEmail($row['email']);
        $obj->setTelefone($row['telefone']);
        $obj->setCidade($row['cidade']);
        $obj->setEstado($row['estado']);
        $obj->setEndereco($row['endereco'] ?? '');
        return $obj;
    }

    public function select(): array {
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query("SELECT * FROM cliente ORDER BY nome") as $row)
            $lst[] = $this->hydrate($row);
        Conexao::desconectar();
        return $lst;
    }

    public function selectById(int $id): ?\MODEL\Cliente {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM cliente WHERE id=?");
        $q->execute([$id]);
        $row = $q->fetch();
        Conexao::desconectar();
        return $row ? $this->hydrate($row) : null;
    }

    public function selectByNome(string $nome): array {
        $con = Conexao::conectar();
        $q   = $con->prepare("SELECT * FROM cliente WHERE nome LIKE ? ORDER BY nome");
        $q->execute(["%$nome%"]);
        $lst = [];
        foreach ($q->fetchAll() as $row)
            $lst[] = $this->hydrate($row);
        Conexao::desconectar();
        return $lst;
    }

    public function insert(\MODEL\Cliente $o): bool {
        $sql = "INSERT INTO cliente (nome,cpf,email,telefone,cidade,estado,endereco) VALUES (?,?,?,?,?,?,?)";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$o->getNome(),$o->getCpf(),$o->getEmail(),$o->getTelefone(),$o->getCidade(),$o->getEstado(),$o->getEndereco()]);
        Conexao::desconectar();
        return $res;
    }

    public function update(\MODEL\Cliente $o): bool {
        $sql = "UPDATE cliente SET nome=?,cpf=?,email=?,telefone=?,cidade=?,estado=?,endereco=? WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$o->getNome(),$o->getCpf(),$o->getEmail(),$o->getTelefone(),$o->getCidade(),$o->getEstado(),$o->getEndereco(),$o->getId()]);
        Conexao::desconectar();
        return $res;
    }

    public function delete(int $id): bool {
        $con = Conexao::conectar();
        $q   = $con->prepare("DELETE FROM cliente WHERE id=?");
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }
}
