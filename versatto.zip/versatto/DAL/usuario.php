<?php
namespace DAL;

include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/DAL/conexao.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/versatto/MODEL/usuario.php";

class Usuario {

    public function selectByUsuario(string $usuario): ?\MODEL\Usuario {
        $sql = "SELECT * FROM usuario WHERE usuario = ? LIMIT 1";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $q->execute([$usuario]);
        $row = $q->fetch();
        Conexao::desconectar();
        if (!$row) return null;
        $obj = new \MODEL\Usuario();
        $obj->setId((int)$row['id']);
        $obj->setNome($row['nome']);
        $obj->setUsuario($row['usuario']);
        $obj->setSenha($row['senha']);
        $obj->setNivel((int)$row['nivel']);
        return $obj;
    }

    public function select(): array {
        $sql = "SELECT * FROM usuario ORDER BY nome";
        $con = Conexao::conectar();
        $lst = [];
        foreach ($con->query($sql) as $row) {
            $obj = new \MODEL\Usuario();
            $obj->setId((int)$row['id']);
            $obj->setNome($row['nome']);
            $obj->setUsuario($row['usuario']);
            $obj->setSenha($row['senha']);
            $obj->setNivel((int)$row['nivel']);
            $lst[] = $obj;
        }
        Conexao::desconectar();
        return $lst;
    }

    public function insert(\MODEL\Usuario $u): bool {
        $sql = "INSERT INTO usuario (nome, usuario, senha, nivel) VALUES (?,?,MD5(?),?)";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$u->getNome(), $u->getUsuario(), $u->getSenha(), $u->getNivel()]);
        Conexao::desconectar();
        return $res;
    }

    public function update(\MODEL\Usuario $u): bool {
        $sql = "UPDATE usuario SET nome=?, usuario=?, nivel=? WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$u->getNome(), $u->getUsuario(), $u->getNivel(), $u->getId()]);
        Conexao::desconectar();
        return $res;
    }

    public function delete(int $id): bool {
        $sql = "DELETE FROM usuario WHERE id=?";
        $con = Conexao::conectar();
        $q   = $con->prepare($sql);
        $res = $q->execute([$id]);
        Conexao::desconectar();
        return $res;
    }
}
