<?php
namespace MODEL;

class Cliente {
    private ?int    $id       = null;
    private ?string $nome     = null;
    private ?string $cpf      = null;
    private ?string $email    = null;
    private ?string $telefone = null;
    private ?string $cidade   = null;
    private ?string $estado   = null;
    private ?string $endereco = null;

    public function getId(): ?int                  { return $this->id; }
    public function setId(int $v): void            { $this->id = $v; }
    public function getNome(): ?string             { return $this->nome; }
    public function setNome(string $v): void       { $this->nome = $v; }
    public function getCpf(): ?string              { return $this->cpf; }
    public function setCpf(string $v): void        { $this->cpf = $v; }
    public function getEmail(): ?string            { return $this->email; }
    public function setEmail(string $v): void      { $this->email = $v; }
    public function getTelefone(): ?string         { return $this->telefone; }
    public function setTelefone(string $v): void   { $this->telefone = $v; }
    public function getCidade(): ?string           { return $this->cidade; }
    public function setCidade(string $v): void     { $this->cidade = $v; }
    public function getEstado(): ?string           { return $this->estado; }
    public function setEstado(string $v): void     { $this->estado = $v; }
    public function getEndereco(): ?string         { return $this->endereco; }
    public function setEndereco(string $v): void   { $this->endereco = $v; }
}
