<?php
namespace MODEL;

class Venda {
    private ?int    $id         = null;
    private ?int    $cliente    = null;
    private ?string $data_venda = null;
    private ?float  $total      = null;
    private ?string $observacao = null;

    public function getId(): ?int                  { return $this->id; }
    public function setId(int $v): void            { $this->id = $v; }
    public function getCliente(): ?int             { return $this->cliente; }
    public function setCliente(int $v): void       { $this->cliente = $v; }
    public function getDataVenda(): ?string        { return $this->data_venda; }
    public function setDataVenda(string $v): void  { $this->data_venda = $v; }
    public function getTotal(): ?float             { return $this->total; }
    public function setTotal(float $v): void       { $this->total = $v; }
    public function getObservacao(): ?string       { return $this->observacao; }
    public function setObservacao(string $v): void { $this->observacao = $v; }
}
