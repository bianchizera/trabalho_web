<?php
namespace MODEL;

class Produto {
    private ?int    $id           = null;
    private ?string $descricao    = null;
    private ?int    $tipoproduto  = null;
    private ?int    $fornecedor   = null;
    private ?float  $estoque      = null;
    private ?float  $preco_compra = null;
    private ?float  $preco_venda  = null;
    private ?string $unidade      = null;

    public function getId(): ?int                   { return $this->id; }
    public function setId(int $v): void             { $this->id = $v; }
    public function getDescricao(): ?string         { return $this->descricao; }
    public function setDescricao(string $v): void   { $this->descricao = $v; }
    public function getTipoproduto(): ?int          { return $this->tipoproduto; }
    public function setTipoproduto(int $v): void    { $this->tipoproduto = $v; }
    public function getFornecedor(): ?int           { return $this->fornecedor; }
    public function setFornecedor(int $v): void     { $this->fornecedor = $v; }
    public function getEstoque(): ?float            { return $this->estoque; }
    public function setEstoque(float $v): void      { $this->estoque = $v; }
    public function getPrecoCompra(): ?float        { return $this->preco_compra; }
    public function setPrecoCompra(float $v): void  { $this->preco_compra = $v; }
    public function getPrecoVenda(): ?float         { return $this->preco_venda; }
    public function setPrecoVenda(float $v): void   { $this->preco_venda = $v; }
    public function getUnidade(): ?string           { return $this->unidade; }
    public function setUnidade(string $v): void     { $this->unidade = $v; }
}