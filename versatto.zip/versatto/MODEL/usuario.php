<?php
namespace MODEL;
class Usuario {
    private ?int $id = null;
    private ?string $nome = null;
    private ?string $usuario = null;
    private ?string $senha = null;
    private ?int $nivel = null;

    public function getId(): ?int { return $this->id; }
    public function setId(int $id): void { $this->id = $id; }
    public function getNome(): ?string { return $this->nome; }
    public function setNome(string $nome): void { $this->nome = $nome; }
    public function getUsuario(): ?string { return $this->usuario; }
    public function setUsuario(string $usuario): void { $this->usuario = $usuario; }
    public function getSenha(): ?string { return $this->senha; }
    public function setSenha(string $senha): void { $this->senha = $senha; }
    public function getNivel(): ?int { return $this->nivel; }
    public function setNivel(int $nivel): void { $this->nivel = $nivel; }
}
