<?php
namespace MODEL;

class Itemcompra {
    private ?int   $id           = null;
    private ?int   $compra       = null;
    private ?int   $produto      = null;
    private ?float $quantidade   = null;
    private ?float $preco_compra = null;
    private ?float $subtotal     = null;

    public function getId(): ?int                   { return $this->id; }
    public function setId(int $v): void             { $this->id = $v; }
    public function getCompra(): ?int               { return $this->compra; }
    public function setCompra(int $v): void         { $this->compra = $v; }
    public function getProduto(): ?int              { return $this->produto; }
    public function setProduto(int $v): void        { $this->produto = $v; }
    public function getQuantidade(): ?float         { return $this->quantidade; }
    public function setQuantidade(float $v): void   { $this->quantidade = $v; }
    public function getPrecoCompra(): ?float        { return $this->preco_compra; }
    public function setPrecoCompra(float $v): void  { $this->preco_compra = $v; }
    public function getSubtotal(): ?float           { return $this->subtotal; }
    public function setSubtotal(float $v): void     { $this->subtotal = $v; }
}
