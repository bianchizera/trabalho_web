<?php
namespace MODEL;

class Fornecedor {
    private ?int    $id       = null;
    private ?string $razao    = null;
    private ?string $cnpj     = null;
    private ?string $email    = null;
    private ?string $telefone = null;
    private ?string $cidade   = null;
    private ?string $estado   = null;
    private ?string $contato  = null;

    public function getId(): ?int                 { return $this->id; }
    public function setId(int $v): void           { $this->id = $v; }
    public function getRazao(): ?string           { return $this->razao; }
    public function setRazao(string $v): void     { $this->razao = $v; }
    public function getCnpj(): ?string            { return $this->cnpj; }
    public function setCnpj(string $v): void      { $this->cnpj = $v; }
    public function getEmail(): ?string           { return $this->email; }
    public function setEmail(string $v): void     { $this->email = $v; }
    public function getTelefone(): ?string        { return $this->telefone; }
    public function setTelefone(string $v): void  { $this->telefone = $v; }
    public function getCidade(): ?string          { return $this->cidade; }
    public function setCidade(string $v): void    { $this->cidade = $v; }
    public function getEstado(): ?string          { return $this->estado; }
    public function setEstado(string $v): void    { $this->estado = $v; }
    public function getContato(): ?string         { return $this->contato; }
    public function setContato(string $v): void   { $this->contato = $v; }
}
