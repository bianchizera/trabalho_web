<?php
namespace MODEL;

class Itemvenda {
    private ?int   $id          = null;
    private ?int   $venda       = null;
    private ?int   $produto     = null;
    private ?float $quantidade  = null;
    private ?float $preco_venda = null;
    private ?float $subtotal    = null;

    public function getId(): ?int                  { return $this->id; }
    public function setId(int $v): void            { $this->id = $v; }
    public function getVenda(): ?int               { return $this->venda; }
    public function setVenda(int $v): void         { $this->venda = $v; }
    public function getProduto(): ?int             { return $this->produto; }
    public function setProduto(int $v): void       { $this->produto = $v; }
    public function getQuantidade(): ?float        { return $this->quantidade; }
    public function setQuantidade(float $v): void  { $this->quantidade = $v; }
    public function getPrecoVenda(): ?float        { return $this->preco_venda; }
    public function setPrecoVenda(float $v): void  { $this->preco_venda = $v; }
    public function getSubtotal(): ?float          { return $this->subtotal; }
    public function setSubtotal(float $v): void    { $this->subtotal = $v; }
}
