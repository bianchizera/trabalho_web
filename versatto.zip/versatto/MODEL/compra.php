<?php
namespace MODEL;

class Compra {
    private ?int    $id          = null;
    private ?int    $fornecedor  = null;
    private ?string $data_compra = null;
    private ?float  $total       = null;
    private ?string $observacao  = null;

    public function getId(): ?int                   { return $this->id; }
    public function setId(int $v): void             { $this->id = $v; }
    public function getFornecedor(): ?int           { return $this->fornecedor; }
    public function setFornecedor(int $v): void     { $this->fornecedor = $v; }
    public function getDataCompra(): ?string        { return $this->data_compra; }
    public function setDataCompra(string $v): void  { $this->data_compra = $v; }
    public function getTotal(): ?float              { return $this->total; }
    public function setTotal(float $v): void        { $this->total = $v; }
    public function getObservacao(): ?string        { return $this->observacao; }
    public function setObservacao(string $v): void  { $this->observacao = $v; }
}
