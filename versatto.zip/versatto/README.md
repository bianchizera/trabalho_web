# Versatto - Móveis Planejados
## Sistema de Controle de Estoque — PHP + MySQL + Materialize CSS

---

## 👥 Grupo
- Aluno 1
- Aluno 2
- Aluno 3
- Aluno 4

---

## 📋 Requisitos Atendidos

| Requisito | Status |
|---|---|
| 4 CRUDs completos (Cliente, Fornecedor, Produto, TipoProduto) | ✅ |
| Framework CSS Materialize | ✅ |
| Movimentação de estoque (Compra/Venda com atualização automática) | ✅ |
| Validação em 3+ formulários (Cliente, Fornecedor, Produto) | ✅ |
| Página principal com navbar e menu sidenav | ✅ |
| Controle de acesso com login/senha (MD5) | ✅ |
| Passagem de valores GET/POST | ✅ |
| GitHub com histórico de commits | ✅ |
| Imagens (logo Versatto) + relatórios PDF | ✅ |
| MVC manual sem frameworks prontos | ✅ |
| Testes unitários (models) | ✅ |

---

## 🛠️ Instalação no XAMPP

### 1. Clonar / copiar o projeto
```
Copie a pasta `versatto` para:
C:\xampp\htdocs\versatto
```

### 2. Instalar o FPDF (para geração de PDF)
- Acesse http://www.fpdf.org e baixe `fpdf.php`
- Crie a pasta: `C:\xampp\htdocs\versatto\lib\fpdf\`
- Coloque o arquivo `fpdf.php` dentro desta pasta

### 3. Criar o banco de dados
- Abra o XAMPP e inicie **Apache** e **MySQL**
- Acesse http://localhost/phpmyadmin
- Clique em **Importar**
- Selecione o arquivo: `versatto/DAL/versatto.sql`
- Clique em **Executar**

### 4. Configurar a conexão (se necessário)
Edite o arquivo `versatto/DAL/conexao.php`:
```php
private static string $dbNome    = 'versatto';   // nome do banco
private static string $dbHost    = 'localhost';
private static string $dbUsuario = 'root';        // usuário MySQL
private static string $dbSenha   = '';            // senha MySQL (padrão XAMPP = vazio)
```

### 5. Acessar o sistema
Abra o navegador e acesse:
```
http://localhost/versatto/VIEW/index.php
```

---

## 🔑 Usuários padrão

| Usuário | Senha | Nível |
|---|---|---|
| `admin` | `admin123` | Administrador |
| `operador` | `op123` | Operador |

---

## 🗂️ Estrutura de Pastas

```
versatto/
├── DAL/                    ← Data Access Layer (acesso ao banco)
│   ├── conexao.php
│   ├── cliente.php
│   ├── fornecedor.php
│   ├── produto.php
│   ├── tipoproduto.php
│   ├── compra.php
│   ├── venda.php
│   ├── usuario.php
│   └── versatto.sql        ← Script do banco de dados
│
├── MODEL/                  ← Modelos (POO)
│   ├── cliente.php
│   ├── fornecedor.php
│   ├── produto.php
│   ├── tipoproduto.php
│   ├── compra.php
│   ├── itemcompra.php
│   ├── venda.php
│   ├── itemvenda.php
│   └── usuario.php
│
├── VIEW/                   ← Views (interface)
│   ├── index.php           ← Login
│   ├── login.php           ← Processa login
│   ├── logout.php
│   ├── menu.php            ← Navbar (incluído em todas as páginas)
│   ├── footer.php          ← Rodapé
│   ├── home.php            ← Página inicial
│   ├── css/style.css
│   ├── js/app.js
│   ├── images/logo.jpeg
│   ├── CLIENTE/            ← CRUD Cliente
│   ├── FORNECEDOR/         ← CRUD Fornecedor
│   ├── PRODUTO/            ← CRUD Produto
│   ├── TIPOPRODUTO/        ← CRUD Tipo de Produto
│   ├── COMPRA/             ← Movimentação entrada
│   ├── VENDA/              ← Movimentação saída
│   └── RELATORIO/          ← Relatórios web + PDF
│
├── lib/fpdf/               ← Biblioteca FPDF (instalar manualmente)
│   └── fpdf.php
│
└── tests/
    └── TesteModels.php     ← Testes unitários
```

---

## 🧪 Executando os Testes Unitários

No terminal (dentro da pasta do projeto):
```bash
php tests/TesteModels.php
```
Saída esperada: todos os testes passando ✅

---

## ☁️ Deploy Gratuito (InfinityFree)

### Opção 1 — InfinityFree (recomendado para PHP + MySQL)
1. Crie conta em https://infinityfree.net
2. Crie um hosting gratuito
3. No **File Manager** ou via **FTP** (FTP usa FileZilla):
   - Host: `ftpupload.net`
   - Usuário e senha: fornecidos pelo InfinityFree
   - Faça upload da pasta `versatto` para `htdocs/`
4. No **MySQL Databases** do painel InfinityFree:
   - Crie um banco e um usuário
   - Importe o arquivo `versatto.sql`
   - Atualize `DAL/conexao.php` com as credenciais fornecidas
5. Acesse pelo link fornecido: `http://seudominio.infinityfreeapp.com/versatto/VIEW/index.php`

### Opção 2 — 000webhost (Hostinger gratuito)
1. Crie conta em https://www.000webhost.com
2. Siga os mesmos passos de upload e banco acima

### ⚠️ Atenção no deploy
- Hosts gratuitos geralmente bloqueiam `MD5` nativo do MySQL; a criptografia já está sendo feita via `md5()` do PHP, então funciona normalmente.
- Verifique se o PHP 8.0+ está disponível.

---

## 🔄 Fluxo de Negócio

```
COMPRA → atualiza estoque (+qtd) + atualiza preço de compra
       → preço de venda = preço de compra × 1,20 (automático)

VENDA  → verifica estoque disponível
       → baixa estoque (-qtd)
       → bloqueia se estoque insuficiente
```

---

## 🛡️ Segurança implementada
- Senhas gravadas em MD5 no banco
- Proteção de sessão em todas as páginas protegidas
- Uso de PDO com prepared statements (proteção contra SQL Injection)
- `htmlspecialchars()` em todas as saídas (proteção contra XSS)

---

## 📌 Tecnologias utilizadas
- **PHP 8+** — Backend / lógica MVC
- **MySQL** — Banco de dados relacional
- **Materialize CSS 1.0** — Framework de estilo
- **FPDF** — Geração de relatórios PDF
- **JavaScript** puro — Validações e itens dinâmicos
- **XAMPP** — Ambiente de desenvolvimento local
