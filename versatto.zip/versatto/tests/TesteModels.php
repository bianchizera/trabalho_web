<?php
/**
 * Testes Unitários - Versatto Móveis Planejados
 * Execução: php tests/TesteModels.php
 * (não requer framework, testes manuais simples)
 */

require_once __DIR__ . '/../MODEL/cliente.php';
require_once __DIR__ . '/../MODEL/fornecedor.php';
require_once __DIR__ . '/../MODEL/produto.php';
require_once __DIR__ . '/../MODEL/tipoproduto.php';
require_once __DIR__ . '/../MODEL/compra.php';
require_once __DIR__ . '/../MODEL/venda.php';
require_once __DIR__ . '/../MODEL/itemcompra.php';
require_once __DIR__ . '/../MODEL/itemvenda.php';
require_once __DIR__ . '/../MODEL/usuario.php';

$passou = 0;
$falhou = 0;

function assert_eq($descricao, $esperado, $obtido): void {
    global $passou, $falhou;
    if ($esperado === $obtido) {
        echo "\033[32m  ✓ $descricao\033[0m\n";
        $passou++;
    } else {
        echo "\033[31m  ✗ $descricao | Esperado: " . var_export($esperado,true) . " | Obtido: " . var_export($obtido,true) . "\033[0m\n";
        $falhou++;
    }
}

echo "\n\033[1;34m=== TESTES UNITÁRIOS - VERSATTO ===\033[0m\n\n";

// ---- MODEL\Cliente ----
echo "\033[1mMODEL\\Cliente\033[0m\n";
$c = new \MODEL\Cliente();
$c->setId(1);
$c->setNome('João Silva');
$c->setCpf('123.456.789-09');
$c->setEmail('joao@email.com');
$c->setTelefone('(18)99999-1111');
$c->setCidade('Assis');
$c->setEstado('SP');
$c->setEndereco('Rua A, 100');

assert_eq('getId retorna 1',              1,              $c->getId());
assert_eq('getNome retorna nome',         'João Silva',   $c->getNome());
assert_eq('getCpf retorna CPF',           '123.456.789-09', $c->getCpf());
assert_eq('getEmail retorna e-mail',      'joao@email.com', $c->getEmail());
assert_eq('getTelefone retorna telefone', '(18)99999-1111', $c->getTelefone());
assert_eq('getCidade retorna cidade',     'Assis',        $c->getCidade());
assert_eq('getEstado retorna UF',         'SP',           $c->getEstado());
assert_eq('getEndereco retorna endereço', 'Rua A, 100',   $c->getEndereco());

// ---- MODEL\Fornecedor ----
echo "\n\033[1mMODEL\\Fornecedor\033[0m\n";
$f = new \MODEL\Fornecedor();
$f->setId(2);
$f->setRazao('MDF Brasil Ltda');
$f->setCnpj('11.222.333/0001-44');
$f->setEmail('mdf@email.com');
$f->setTelefone('(11)3333-1111');
$f->setCidade('São Paulo');
$f->setEstado('SP');
$f->setContato('Marcos');

assert_eq('getId retorna 2',            2,                      $f->getId());
assert_eq('getRazao retorna razão',     'MDF Brasil Ltda',      $f->getRazao());
assert_eq('getCnpj retorna CNPJ',       '11.222.333/0001-44',   $f->getCnpj());
assert_eq('getContato retorna contato', 'Marcos',               $f->getContato());

// ---- MODEL\Tipoproduto ----
echo "\n\033[1mMODEL\\Tipoproduto\033[0m\n";
$tp = new \MODEL\Tipoproduto();
$tp->setId(1);
$tp->setDescricao('Cozinha Planejada');
assert_eq('getId retorna 1',             1,                 $tp->getId());
assert_eq('getDescricao retorna desc',   'Cozinha Planejada', $tp->getDescricao());

// ---- MODEL\Produto ----
echo "\n\033[1mMODEL\\Produto\033[0m\n";
$p = new \MODEL\Produto();
$p->setId(10);
$p->setDescricao('Armário 3 Portas');
$p->setTipoproduto(1);
$p->setEstoque(5.0);
$p->setPrecoCompra(1200.0);
$p->setPrecoVenda(1440.0);
$p->setUnidade('un');

assert_eq('getId retorna 10',            10,               $p->getId());
assert_eq('getDescricao retorna desc',   'Armário 3 Portas', $p->getDescricao());
assert_eq('getEstoque retorna 5.0',      5.0,              $p->getEstoque());
assert_eq('getPrecoCompra retorna 1200', 1200.0,           $p->getPrecoCompra());
assert_eq('getPrecoVenda retorna 1440',  1440.0,           $p->getPrecoVenda());
assert_eq('getUnidade retorna un',       'un',             $p->getUnidade());

// Regra de negócio: preço de venda = preço de compra * 1.20
$precoCompra = 1000.0;
$precoVenda  = round($precoCompra * 1.20, 2);
assert_eq('Preço venda = compra * 1.20', 1200.0, $precoVenda);

// ---- MODEL\Compra ----
echo "\n\033[1mMODEL\\Compra\033[0m\n";
$compra = new \MODEL\Compra();
$compra->setId(1);
$compra->setFornecedor(2);
$compra->setDataCompra('2026-06-01');
$compra->setTotal(3600.0);
$compra->setObservacao('Reposição');

assert_eq('getFornecedor retorna 2',      2,           $compra->getFornecedor());
assert_eq('getDataCompra retorna data',   '2026-06-01',$compra->getDataCompra());
assert_eq('getTotal retorna 3600',        3600.0,      $compra->getTotal());
assert_eq('getObservacao retorna texto',  'Reposição', $compra->getObservacao());

// ---- MODEL\Itemcompra ----
echo "\n\033[1mMODEL\\Itemcompra\033[0m\n";
$ic = new \MODEL\Itemcompra();
$ic->setCompra(1); $ic->setProduto(3); $ic->setQuantidade(2.0);
$ic->setPrecoCompra(1200.0); $ic->setSubtotal(2400.0);
assert_eq('getQuantidade retorna 2.0',   2.0,   $ic->getQuantidade());
assert_eq('getSubtotal retorna 2400',    2400.0,$ic->getSubtotal());
$subtotalCalc = $ic->getQuantidade() * $ic->getPrecoCompra();
assert_eq('Subtotal = qtd * preço',      2400.0,$subtotalCalc);

// ---- MODEL\Venda ----
echo "\n\033[1mMODEL\\Venda\033[0m\n";
$v = new \MODEL\Venda();
$v->setId(1); $v->setCliente(1); $v->setDataVenda('2026-06-05');
$v->setTotal(1440.0); $v->setObservacao('Venda teste');
assert_eq('getCliente retorna 1',    1,           $v->getCliente());
assert_eq('getDataVenda retorna data','2026-06-05',$v->getDataVenda());
assert_eq('getTotal retorna 1440',   1440.0,      $v->getTotal());

// ---- MODEL\Usuario ----
echo "\n\033[1mMODEL\\Usuario\033[0m\n";
$u = new \MODEL\Usuario();
$u->setId(1); $u->setNome('Admin'); $u->setUsuario('admin');
$u->setSenha(md5('admin123')); $u->setNivel(1);
assert_eq('getNome retorna Admin',  'Admin', $u->getNome());
assert_eq('getUsuario retorna admin','admin',$u->getUsuario());
assert_eq('getSenha é MD5 válido',  32, strlen($u->getSenha()));
assert_eq('getNivel retorna 1',     1,  $u->getNivel());
assert_eq('MD5 admin123 correto',   md5('admin123'), $u->getSenha());

// ---- Resultado final ----
echo "\n\033[1m" . str_repeat('=', 40) . "\033[0m\n";
$total_t = $passou + $falhou;
echo "\033[1;32mPassaram: $passou / $total_t\033[0m";
if ($falhou > 0) echo "\033[1;31m   Falharam: $falhou\033[0m";
echo "\n\n";
exit($falhou > 0 ? 1 : 0);
